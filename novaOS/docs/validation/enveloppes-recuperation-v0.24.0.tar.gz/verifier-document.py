"""Vérification documentaire des offsets, bornes et références. Aucun raccord."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
reference = "2ae44a24835a9afef2f27f43aa11748184642488"
document = root / "novaOS/docs/novaauth-enveloppes-recuperation-v0.24.0.md"
text = document.read_text()
tables = []
current = []
for line in text.splitlines() + [""]:
    match = re.match(r"\| (\d+) \| (\d+) \| (\d+) \|", line)
    if match:
        first, last, size = map(int, match.groups())
        assert last - first + 1 == size, line
        if current:
            assert first == current[-1][1] + 1, line
        current.append((first, last, size))
    elif current:
        tables.append(current)
        current = []
assert [(t[0][0], t[-1][1] + 1) for t in tables] == [
    (0,292), (0,122), (0,344), (248,376), (0,324)
]
assert sum(row[2] for row in tables[0]) == 292
assert sum(row[2] for row in tables[1]) == 122
assert sum(row[2] for row in tables[2]) == 344
assert sum(row[2] for row in tables[2][:-3]) + sum(row[2] for row in tables[3]) == 376
assert sum(row[2] for row in tables[4]) == 324
assert 228 + 64 == 292 and 260 + 64 == 324
assert 58 + 32 + 122 + 16 == 228
assert 58 + 32 + 154 + 16 == 260

sources = [
    "novaOS/docs/novaauth-recuperation-2-sur-2-v0.24.0.md",
    "novaOS/user/novaauth/transport_qemu/etat.rs",
    "novaOS/user/novaauth/transport_qemu/cellule.rs",
    "novaOS/user/novaauth/transport_qemu/port_invite.rs",
    "novaOS/user/novaauth/transport_qemu/adaptateur.rs",
    "novaOS/user/novaauth/transport_qemu/tests.rs",
    "novaOS/user/novaauth/transport_qemu/mesure_memoire.py",
    "novaOS/user/novaauth/transport_qemu/qualification_tls.py",
    "novaOS/user/novaauth/service/src/bin/common/canal.rs",
    "novaOS/tests/abi_registre.py",
    "novaOS/abi/syscalls.toml",
]
audit = {}
published = {}
for name in sources:
    data = subprocess.check_output(["git","show",reference+":"+name],cwd=root)
    published[name] = data.decode()
    local = (root/name).read_bytes()
    audit[name] = {
        "sha256_reference": hashlib.sha256(data).hexdigest(),
        "sha256_local": hashlib.sha256(local).hexdigest(),
        "identique": local == data,
    }
for name in (
    "novaOS/user/novaauth/autorite_qemu/recuperation.py",
    "novaOS/user/novaauth/recuperation/src/lib.rs",
):
    audit[name] = {
        "statut": "brouillon local non publie, lecture pour la revue",
        "sha256_local": hashlib.sha256((root/name).read_bytes()).hexdigest(),
    }
assert "const META: usize = 56" in published[sources[1]]
assert "const PAGE: usize = 4096" in published[sources[2]]
assert "const HEADER: usize = 64" in published[sources[2]]
assert "const MAX: usize = 512 - HEADER" in published[sources[2]]
assert "const PART: usize = 96" in published[sources[3]]
assert "META <= 256 && EXTRA <= 256" in published[sources[4]]
assert "size_of::<Port>() <= 256" in published[sources[3]]
assert "[0; 2070]" in published["novaOS/user/novaauth/service/src/bin/common/canal.rs"]
assert "MaxFragmentLength::Bits11" in published["novaOS/user/novaauth/service/src/bin/common/canal.rs"]
assert "(1, 448, 449, 2048)" in published[sources[7]]
assert audit["novaOS/tests/abi_registre.py"]["identique"]
abi = (out/"abi-registre.log").read_text()
assert "Ran 9 tests" in abi and abi.rstrip().endswith("OK")
import tomllib
assert len(tomllib.loads(published["novaOS/abi/syscalls.toml"])["call"]) == 48

results = {
    "reference": reference,
    "portee": "verification documentaire, aucune qualification du raccord",
    "tables": tables,
    "tailles": {"requete":292,"corps_requete":122,"remise":324,"corps_remise":154,
               "contexte_v1":344,"contexte_v2":376,"metadonnees":56},
    "fragments_enveloppe_nue": {"requete":[96,96,96,4],"remise":[96,96,96,36]},
    "calcul_record_TLS_sans_padding_avec_encadrement_applicatif_16": {
        "requete":292+16+22,"remise":324+16+22,
    },
    "ABI": {"tests":9,"resultat":"OK","selecteurs":48},
    "tests_raccord_292_et_contexte_v2": "non verifies",
}
assert results["calcul_record_TLS_sans_padding_avec_encadrement_applicatif_16"]["requete"] <= 448
assert results["calcul_record_TLS_sans_padding_avec_encadrement_applicatif_16"]["remise"] <= 448

links = []
future = {
    "validation/enveloppes-recuperation-v0.24.0.tar.gz",
    "validation/enveloppes-recuperation-v0.24.0.tar.gz.sha256",
}
def heading_id(value):
    value = re.sub(r"[^\w\s-]", "", value.lower(), flags=re.UNICODE)
    return value.replace(" ","-")
for target in re.findall(r"\]\(([^)]+)\)", text):
    if target.startswith("https://"):
        continue
    name, _, anchor = target.partition("#")
    path = (document.parent/name).resolve()
    if not path.is_file():
        if name in future:
            links.append({"cible":target,"etat":"archive a construire puis reverifier"})
            continue
        raise AssertionError(target)
    if anchor:
        headings = [heading_id(h) for h in re.findall(r"^#+ (.+)$",path.read_text(),re.M)]
        assert anchor in headings, (target,headings)
    links.append({"cible":target,"etat":"OK"})
initial = json.loads((out/"etat-local-initial.json").read_text())
for name, metadata in initial["fichiers"].items():
    data=(root/name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == metadata["sha256"], name
results["travaux_locaux_preserves"] = len(initial["fichiers"])
for filename, value in (
    ("calculs.json",results),("sources.json",audit),("liens.json",links),
):
    (out/filename).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n")
(out/"document-revu.md").write_bytes(document.read_bytes())
print(json.dumps(results,ensure_ascii=False,indent=2))
