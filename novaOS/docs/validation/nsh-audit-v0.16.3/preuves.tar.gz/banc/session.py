from preparer import *
import sys,time,os,select,shutil
sys.path.insert(0,str(R/'novaOS/tests'))
from cli import Terminal
def clean(raw):
 t=raw.decode('utf-8','replace').replace('\r\n','\n')
 t=re.sub(r'(?:CLI (?:mem pid=|collecte pid=|spawn image=|repos pages=)|RAM phase=cli_|PROC pid=[0-9]|BLOC parcours i=|\[statut (?:sortie|faute) )[^^\n]*\n','',t)
 return t
def send(t,cmd,page=False):
 t.vm.stdin.write(cmd.encode()+b'\n'); t.until(b'\r\n')
 if not page: return t.until(b'nsh> ')[:-5]
 chunks=[]
 while True:
  while not any(m in t.pending for m in (b'--More--',b'nsh> ')):
   if not select.select([t.vm.stdout],[],[],50)[0]:raise TimeoutError(cmd)
   data=os.read(t.vm.stdout.fileno(),65536)
   if not data:raise EOFError(cmd)
   t.log.write(data);t.pending+=data
  if b'--More--' in t.pending:
   chunks.append(t.until(b'--More--')[:-8]);t.vm.stdin.write(b' ')
   t.until(b'\r\n')
  else:return b''.join(chunks)+t.until(b'nsh> ')[:-5]
def command(t,cmd,page=False):
 raw=send(t,cmd,page); after=send(t,'echo AUDIT_RC=$?')
 match=re.search(rb'AUDIT_RC=(\d+)\r\n',after)
 if not match:raise ValueError((cmd,after))
 return int(match[1]),clean(raw)
if __name__=='__main__':
 p=W/'pilote.raw';shutil.copyfile(W/'base-512.raw',p)
 with Terminal('aarch64',512,p,'audit-pilote',test=False) as t:
  t.until(b'nsh> ')
  for c in ['cd /test-nsh','ls -l','cat /aux/sanslf','cd alpha.txt','ls documents/*','wc /aux/multi','pw\t','cat inexistant','ps','more /aux/multi','cat /aux/été','head alpha.txt beta.txt']:
   print(c,command(t,c),flush=True)
  t.exit()
