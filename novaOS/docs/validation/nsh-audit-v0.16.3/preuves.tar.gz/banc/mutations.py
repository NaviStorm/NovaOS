from session import *
# (identifiant, commande, précondition supplémentaire de l'image, code, effet attendu)
cases=[
 ('F01','mkdir nouveau','',0,'mkdir:nouveau'),('F02','mkdir nouveau','d:nouveau',27,'aucun'),
 ('F03','rmdir nouveau','d:nouveau',0,'del:nouveau'),('F04','rmdir documents','',28,'aucun'),
 ('F05','touch nouveau.txt','',0,'new:nouveau.txt'),('F06','touch alpha.txt','',0,'dates'),
 ('F07','cp alpha.txt copie.txt','',0,'cp:alpha.txt:copie.txt'),('F08','cp alpha.txt copie.txt','f:copie.txt',27,'aucun'),
 ('F09','cp alpha.txt beta.txt','',27,'aucun'),('F10','cp -R documents sauvegarde','',0,'cp:documents:sauvegarde'),
 ('F11','cp alpha.txt beta.txt sauvegarde/','d:sauvegarde',0,'multi'),
 ('F12','mv copie.txt deplace.txt','f:copie.txt',0,'mv:copie.txt:deplace.txt'),
 ('F13','mv deplace.txt beta.txt','f:deplace.txt',27,'aucun'),
 ('F14','mv documents nouveau-nom','',0,'mv:documents:nouveau-nom'),('F15','rm nouveau.txt','f:nouveau.txt',0,'del:nouveau.txt'),
 ('F16','rm -r sauvegarde','tree:sauvegarde',0,'del:sauvegarde'),('F17','rm -rf inexistant','',0,'aucun'),
 ('F18','rm --help','',0,'aide'),('F19','rm --version','',0,'version'),
 ('F20','rm --help alpha.txt beta.txt','',0,'aide'),('F21','rm --version alpha.txt beta.txt','',0,'version')]
def shape(s):return {k:(v['type'],v['sha256']) for k,v in s.items()}
def run(arch,sector):
 for ident,cmd,cond,code,effect in cases:
  name=f'{arch}-{sector}-{ident}';p=W/(name+'.raw');shutil.copyfile(W/f'base-{sector}.raw',p)
  if cond:
   action,leaf=cond.split(':'); absname='/test-nsh/'+leaf; cmds=[]
   if action in ('d','tree'):cmds+=['dir\t'+absname]
   if action in ('f','tree'):
    if action=='tree':cmds+=['dir\t'+absname+'/sous'];absname+='/sous/preuve'
    data=W/'contenus'/('0' if ident=='F08' else '1');cmds+=[f'{data}\t{absname}']
   subprocess.run([W/'fixture','seed',p,str(sector)],input=('\n'.join(cmds)+'\n').encode(),check=True)
  before=snapshot(p,sector,'/');res={}
  with Terminal(arch,sector,p,'audit-'+ident,test=False) as t:
   t.until(b'nsh> ',150)
   assert command(t,'cd /test-nsh')[0]==0
   rc,out=command(t,cmd)
   t.exit()
  after=snapshot(p,sector,'/')
  base='/test-nsh/'; expected=shape(before);wantid={};newids=[]
  if effect=='multi':pairs=[('cp',n,'sauvegarde/'+n) for n in ['alpha.txt','beta.txt']]
  elif effect.split(':')[0] in ('mv','cp'):pairs=[effect.split(':')]
  else:pairs=[]
  for op,a,b in pairs:
   for k in list(before):
    if k==base+a or k.startswith(base+a+'/'):
     dst=base+b+k[len(base+a):];expected[dst]=expected[k]
     if op=='mv':wantid[dst]=before[k]['id'];del expected[k]
     else:newids.append((dst,before[k]['id']))
  if effect.startswith('del:'):
   k=base+effect.split(':')[1];expected={n:v for n,v in expected.items() if n!=k and not n.startswith(k+'/')}
  if effect.startswith('mkdir:'):expected[base+effect.split(':')[1]]=('Directory',None)
  if effect.startswith('new:'):expected[base+effect.split(':')[1]]=('File',hashlib.sha256(b'').hexdigest())
  valid=rc==code and expected==shape(after) and all(after.get(k,{}).get('id')==i for k,i in wantid.items()) and all(after.get(k,{}).get('id')!=i for k,i in newids)
  valid=valid and all(before[k]['id']==after[k]['id'] for k in before.keys()&after.keys())
  if effect=='dates':
   old,new=before[base+'alpha.txt'],after[base+'alpha.txt']
   valid=valid and old['mtime']!=new['mtime'] and new['mtime']==new['atime'] and old['btime']==new['btime']
  if effect=='aide':valid=valid and 'rm [' in out
  if effect=='version':valid=valid and 'NovaOS 0.16.2' in out
  delta={k:[before.get(k),after.get(k)] for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
  protected=['aucun','aide','version']
  if effect in protected:
   for k,(a,b) in delta.items():
    if not a or not b or any(a[f]!=b[f] for f in ('type','id','octets','sha256','mtime','btime','ctime')):valid=False
  obj=dict(id=ident,cmd=cmd,pre=cond,rc=rc,out=out,want=f'{code}, {effect}',status='PASS' if valid else 'FAIL',delta=delta)
  (W/(name+'.json')).write_text(json.dumps(obj,ensure_ascii=False))
  print(ident,rc,obj['status'],flush=True)
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]))
