from session import *
import shlex
arch,s=sys.argv[1],int(sys.argv[2])
base=json.loads((W/f'base-{s}.json').read_text());image=W/f'lecture-{arch}-{s}.raw';shutil.copyfile(W/f'base-{s}.raw',image)
prefix='/test-nsh/'; entries={p[len(prefix):]:v for p,v in base.items() if p.startswith(prefix) and '/' not in p[len(prefix):]}
visible=sorted(n for n in entries if not n.startswith('.'))
def lines(xs):return ''.join(f'{n}\n' for n in xs)
def bydate(name):
 secs,nano=map(int,re.search(r'(-?\d+), (\d+)',entries[name]['mtime']).groups())
 return (-secs,-nano,name)
def short(v):
 if len(v)>550:return f'{len(v.encode())} octets ; SHA-256 '+hashlib.sha256(v.encode()).hexdigest()
 return v
def record(id,cmd,want,predicate,desc=None,rc=0,absence=False,pre='cwd /test-nsh',page=False):
 observed,output=command(t,cmd,page)
 good=observed==rc and predicate(output)
 status='ABSENT' if absence and good else ('PASS' if good else 'FAIL')
 row=dict(id=id,cmd=cmd,pre=pre,want=desc if desc else short(want),rc_attendu=rc,rc=observed,out=short(output),status=status)
 with (W/f'lecture-{arch}-{s}.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
 if status=='FAIL':print('ÉCART',row,flush=True)
def exact(id,cmd,want,**k): record(id,cmd,want,lambda o:o==want,**k)
def inc(id,cmd,sub,**k):record(id,cmd,sub,lambda o:sub in o,**k)
def gnu(util,opts,names):
 tmp=W/f'gnu-{arch}-{s}';tmp.mkdir(exist_ok=True)
 for n in names:
  f=tmp/n.lstrip('/');f.parent.mkdir(exist_ok=True,parents=True);f.write_bytes(files[n.lstrip('/')])
 result=subprocess.check_output(['g'+util,*opts,*[n.lstrip('/') for n in names]],cwd=tmp,env={**os.environ,'LC_ALL':'en_US.UTF-8'}).decode()
 if util=='wc':
  return '\n'.join(' '.join(line.split()).replace(' aux/',' /aux/') for line in result.splitlines())+'\n'
 return result.replace('==> aux/','==> /aux/')
with Terminal(arch,s,image,'audit-lecture',test=False) as t:
 t.until(b'nsh> ',150);assert command(t,'cd /test-nsh')[0]==0
 exact('N01','pwd','/test-nsh\n')
 cwd='/test-nsh'
 for i,(cmd,after,code) in enumerate([('cd documents','/test-nsh/documents',0),('cd ..','/test-nsh',0),('cd documents/sous','/test-nsh/documents/sous',0),('cd ../..','/test-nsh',0),('cd ./documents','/test-nsh/documents',0),('cd /test-nsh','/test-nsh',0),('cd inexistant','/test-nsh',20),('cd alpha.txt','/test-nsh',29),('cd ../../..','/test-nsh',5)],2):
  ident=f'N{i:02}';inc(ident,cmd,{0:'',20:'introuvable',29:'répertoire',5:'refusé'}[code],rc=code,pre='cwd '+cwd);exact(ident+'b','pwd',after+'\n',pre='Après '+cmd);cwd=after
 exact('N11','ls documents/','image.png\nrapport.txt\nsous\n')
 exact('N12','cat documents/rapport.txt','Rapport 2026\n')
 for i,(cmd,want,rc) in enumerate([('cat "notes 2026.txt"','Notes avec espace.\n',0),('cat /aux/été','été 界\n',0),('cat -- /aux/-tiret','tiret\n',0),('cat /aux/'+longname,'long\n',0),('cat documents//rapport.txt','argument invalide',3)],13):
  inc(f'N{i:02}',cmd,want,rc=rc)
 exact('L01','ls',lines(visible));exact('L02','ls -a',lines(sorted(['.',*entries])));exact('L03','ls -A',lines(sorted(entries)))
 def aligned(o,names):
  rows=o.splitlines()
  if len(rows)!=len(names):return False
  starts=[]
  for row,name in zip(rows,names):
   if not row.endswith('  '+name):return False
   p=row[:-len(name)]
   m=re.match(r'^(fichier|répertoire) +(\d+) +(\d{4}-\d\d-\d\d .+?Z) +$',p)
   if not m:return False
   if name in entries and int(m[2])!=entries[name]['octets']:return False
   starts.append((m.end(2),m.start(3),len(p)))
  return len(set(starts))==1
 record('L04','ls -l','',lambda o:aligned(o,visible),'Noms visibles dans l’ordre, tailles et colonnes alignées')
 record('L05','ls -la','',lambda o:aligned(o,sorted(['.',*entries])),'Format long aligné, cachés et point')
 dates={**entries,'.':base['/test-nsh']}
 def chrono(n):
  sec,ns=map(int,re.search(r'(-?\d+), (\d+)',dates[n]['mtime']).groups());return -sec,-ns,n
 record('L06','ls -latr','',lambda o:aligned(o,sorted(dates,key=chrono,reverse=True)),'Ordre mtime croissant, contrôlé sur chaque entrée')
 def listing():
  root='/test-nsh';out=[]
  def tree(p,label):
   members=sorted(k[len(p)+1:] for k in base if k.startswith(p+'/') and '/' not in k[len(p)+1:] and not k[len(p)+1:].startswith('.'))
   out.extend([label+':',*members])
   for n in members:
    if base[p+'/'+n]['type']=='Directory':
     out.append('');tree(p+'/'+n,label+'/'+n)
  tree(root,'.');return lines(out)
 exact('L07','ls -R',listing())
 record('L08','ls --color','',lambda o:re.sub(r'\x1b\[[;\d]*m','',o)==lines(visible) and all(('\x1b[34m'+n+'\x1b[0m') in o for n in visible if entries[n]['type']=='Directory'),'Répertoires en bleu, noms attendus')
 exact('L09','ls -h',lines(visible));inc('L09b','ls -lh /aux/grand','K')
 exact('L10','ls -S',lines(sorted(visible,key=lambda n:(-entries[n]['octets'],n))))
 exact('L11','ls -t',lines(sorted(visible,key=bydate)));exact('L12','ls -r',lines(reversed(visible)))
 exact('L13','ls documents','image.png\nrapport.txt\nsous\n');exact('L14','ls documents/rapport.txt','documents/rapport.txt\n')
 inc('L15','ls inexistant','introuvable',rc=20)
 for i,opt in enumerate(['-Z','--sort=size','--inconnue','-w abc','--color=bogus']):
  record('L'+str(16+i),'ls '+opt,'',lambda o:'invalide' in o or 'prise en charge' in o,'Refus explicite',rc=3)
 txt=sorted(p[len(prefix):] for p in base if p.startswith(prefix) and p.endswith('.txt'))
 for i,(cmd,want,rc) in enumerate([('ls *.txt',lines(n for n in visible if n.endswith('.txt')),0),('ls fichier?.log','fichier1.log\nfichier2.log\n',0),('ls chiffres/test[0-9].txt',lines(f'chiffres/test{n}.txt' for n in (0,5,9)),0),('ls chiffres/test[!5].txt',lines(f'chiffres/test{n}.txt' for n in (0,9)),0),('ls documents/*','documents/image.png\ndocuments/rapport.txt\ndocuments/sous:\nprofond.txt\n',0),('ls **/*.txt',lines(txt),0),('ls documents/**/profond.txt','documents/sous/profond.txt\n',0),('ls *.inexistant','introuvable',20),("ls '*.txt'",'introuvable',20),('ls "*.txt"','introuvable',20),(r'ls \*.txt','introuvable',20),('ls .cache','.cache\n',0),('ls **/*.txt',lines(txt),0),('ls /aux/quota/*','limite atteinte',6),('ls -d /aux/arbre/**/fond','/'+deep+'/fond\n',0),('ls /../../*.txt','refusé',5)],1):
  (inc if rc else exact)(f'G{i:02}',cmd,want,rc=rc)
 for name in ['cat','head','tail','more','wc']:
  for j,paths in enumerate([['/aux/vide'],['/aux/ligne'],['/aux/multi'],['/aux/sanslf'],['/aux/été'],['/aux/ligne','/aux/multi'],['/aux/grand']],1):
   cmd=name+' '+' '.join(paths)
   want=gnu(name if name!='more' else 'cat',[],paths)
   exact(name.upper()+str(j).zfill(2),cmd,want,page=name=='more' and j==7)
  inc(name.upper()+'08',name+' introuvable','introuvable',rc=20)
  inc(name.upper()+'09',name+' ../../aux/ligne','refusé',rc=5)
  record(name.upper()+'10',name+' -Z /aux/ligne','',lambda o:'invalide' in o or 'non prise en charge' in o,'Option refusée, diagnostic',rc=3)
  inc(name.upper()+'11',name+' --help',name+' ');inc(name.upper()+'12',name+' --version','NovaOS 0.16.2')
  opts=({'head':['-n2','--lines=2','-c3','--bytes=3','-q','-v','--quiet','--silent','--verbose'],'tail':['-n2','--lines=2','-c3','--bytes=3','-q','-v','--quiet','--silent','--verbose'],'wc':['-l','-w','-c','-m','-L','--lines','--words','--bytes','--chars','--max-line-length']}).get(name,['--'])
  for j,opt in enumerate(opts,13):
   paths=['/aux/ligne','/aux/multi'];want=gnu('cat' if name=='more' else name,[opt],paths)
   exact(name.upper()+str(j),name+' '+opt+' '+' '.join(paths),want)
 for i,(cmd,want,rc) in enumerate([('nsh scripts/simple.nsh','simple-OK\n',0),('nsh scripts/boucles.nsh',lines('chiffres/test'+str(i)+'.txt' for i in (0,5,9)),0),("nsh -c 'echo bonjour'",'bonjour\n',0),('x=été; echo "$x"','été\n',0),("export y=visible; nsh -c 'echo $y'","visible\n",0),("unset y; test -z \"$y\"",'',0),('false; echo $?','1\n',0),('if false; then echo A; elif true; then echo B; else echo C; fi','B\n',0),('if false; then echo A; else echo C; fi','C\n',0),('for i in a b c; do [ "$i" = a ] && continue; echo "$i"; break; done','b\n',0),('i=0; while test "$i" -lt 1; do echo W; i=1; done','W\n',0),('false && echo NON || echo OUI; ! true','OUI\n',1),(r"""echo '$x' "$x" \*""",'$x été *\n',0),('nsh /aux/imbr.nsh','enfant\nrc=17\n',0),('nsh /aux/vide','',0),('nsh /aux/incorrect.nsh','invalide',3),('nsh ../../aux/imbr.nsh','refusé',5)],1):
  (inc if rc in (3,5) else exact)(f'S{i:02}',cmd,want,rc=rc)
 for i,cmd in enumerate(['ps','top','clear','history','help'],1):inc(f'Y{i:02}',cmd,'commande inconnue',rc=127,absence=True,desc='Commande disponible')
 exact('Y06','echo salut','salut\n');exact('Y07',"alias bon='echo BON'; bon",'BON\n')
 inc('Y08','unalias bon; bon','commande inconnue',rc=127)
 exact('Y09','nsh -c "exit 13"','',rc=13)
 for i,cmd in enumerate(['pw','ca','cd doc','cat alp','cat "notes 2','cd documents/s','cat documents/sous/pro','cat xyz','c'],1):
  inc(f'T{i:02}',cmd+'\t'*(2 if i==9 else 1),'saisie refusée',rc=3,absence=True,desc='Complétion ou liste appropriée, texte utilisable après Tab')
 inc('E01','test 9223372036854775808 -eq 1','invalide',rc=3)
 inc('E02',"nsh -c 'while true; do continue; done'",'limite',rc=6)
 t.exit()
 with (W/f'lecture-{arch}-{s}.jsonl').open('a') as f:
  f.write(json.dumps(dict(id='Y10',cmd='exit',pre='Invite active',want='Fermeture propre du shell',out='BLOC session terminee ok=true',rc=0,status='PASS'))+'\n')
