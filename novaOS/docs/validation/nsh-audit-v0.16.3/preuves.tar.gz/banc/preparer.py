from pathlib import Path
import hashlib,json,subprocess,re
W=Path(__file__).resolve().parent
R=W.parents[2]
HOST=R/'novaFS/target/aarch64-apple-darwin/release/novafs'
dirs=['test-nsh','test-nsh/vide','test-nsh/documents','test-nsh/documents/sous','test-nsh/chiffres','test-nsh/scripts','aux','aux/quota','aux/arbre']
files={k:v.encode() for k,v in {
'alpha.txt':'alpha A\n','beta.txt':'beta BB\n','notes 2026.txt':'Notes avec espace.\n','fichier1.log':'journal un\n','fichier2.log':'journal deux\n','.cache':'caché\n','documents/rapport.txt':'Rapport 2026\n','documents/sous/profond.txt':'Feuille profonde\n','scripts/simple.nsh':'#!/bin/nsh\necho simple-OK\n','scripts/boucles.nsh':'#!/bin/nsh\nfor f in chiffres/*.txt; do echo "$f"; done\n'}.items()}
files['documents/image.png']=bytes.fromhex('89504e470d0a1a0a')
for n in (0,5,9):files[f'chiffres/test{n}.txt']=f'chiffre {n}\n'.encode()
files={'test-nsh/'+k:v for k,v in files.items()}
files.update({'aux/vide':b'','aux/ligne':b'Une ligne\n','aux/multi':b''.join(f'L{i:02}\n'.encode() for i in range(1,16)),'aux/sanslf':b'AB\nCD','aux/été':'été 界\n'.encode(),'aux/-tiret':b'tiret\n','aux/grand':b''.join(f'ligne {i:04} alpha\n'.encode() for i in range(4096)),'aux/incorrect.nsh':b'echo INTERDIT; if true; then echo NON\n','aux/imbr.nsh':b"nsh -c 'echo enfant; return 17'; echo rc=$?\n"})
for i in range(34):files[f'aux/quota/k{i:02}']=b'Q'
deep='aux/arbre'
for i in range(27):
 deep+='/p';dirs.append(deep)
files[deep+'/fond']=b'fond\n'
longname='x'*150
files['aux/'+longname]=b'long\n'
def snapshot(image,s,root='/test-nsh'):
 out=subprocess.check_output([W/'fixture','scan',image,str(s),root]).decode()
 res={}
 for row in out.splitlines():
  name,kind,id,size,rev,b,m,c,a,hexdata=row.split('\t')
  res[name]=dict(type=kind,id=int(id),octets=int(size),revision=int(rev),btime=b,mtime=m,ctime=c,atime=a,sha256=hashlib.sha256(bytes.fromhex(hexdata)).hexdigest() if kind=='File' else None)
 return res
def seed(image,s,items=None):
 staging=W/'contenus';staging.mkdir(exist_ok=True)
 cmds=[]
 for name in dirs:
  if not items or name.startswith(items):cmds.append('dir\t/'+name)
 for i,(p,data) in enumerate(files.items()):
  if items and not p.startswith(items):continue
  src=staging/str(i);src.write_bytes(data);cmds.append(f'{src}\t/{p}')
 subprocess.run([W/'fixture','seed',image,str(s)],input=('\n'.join(cmds)+'\n').encode(),check=True)
if __name__=='__main__':
 for s in [512,4096]:
  old=subprocess.run([HOST,'create','512',str(s)],capture_output=True,check=True)
  ids=re.search(rb'FS=(\w+) LV=(\w+)',old.stderr).groups()
  image=W/f'base-{s}.raw'
  with image.open('xb') as out:subprocess.run([HOST,'migrate-content-p9','512',str(s),*ids],input=old.stdout,stdout=out,check=True)
  seed(image,s)
  snap=snapshot(image,s,'/')
  for k,v in files.items():assert snap['/'+k]['sha256']==hashlib.sha256(v).hexdigest()
  (W/f'base-{s}.json').write_text(json.dumps(snap,ensure_ascii=False,indent=2))
  print(s,len(snap),flush=True)
