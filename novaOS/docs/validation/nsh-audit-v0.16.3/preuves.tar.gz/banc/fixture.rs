use novafs::{Engine, Mode, Device, Kind, codec::Anchor, device::FileImage,time::Timestamp};
use std::{env,io::{self,BufRead},fs::{self,OpenOptions},error::Error};
fn main()->Result<(),Box<dyn Error>>{
 let a: Vec<_>=env::args().collect(); let seed=a[1]=="seed";
 let f=OpenOptions::new().read(true).write(seed).open(&a[2])?;
 let n=f.metadata()?.len()/4096;let d=FileImage::from_file(f,n,a[3].parse()?)?;
 let ids=Anchor::decode(&d.read(0)?,0)?.ids;
 let mut e=Engine::mount_current(d,ids,if seed{Mode::ReadWrite}else{Mode::ReadOnly})?;
 assert!(e.atime_policy().is_some()); e.verify()?;
 if seed {
 for (i,ln) in io::stdin().lock().lines().enumerate(){
  let l=ln?; let (op,p)=l.split_once('\t').unwrap();
  if op=="dir"{e.mkdir(p)?}else{e.create(p)?;let data=fs::read(op)?;
  for (j,c) in data.chunks(8192).enumerate(){e.write(p,(j*8192) as u64,c)?;}}
  e.set_times(p,None,Some(Timestamp::utc(978307200+i as i64,123)?))?;
 }
 e.verify()?;e.unmount()?;
 }else{
 let mut todo=vec![a[4].clone()];
 while let Some(p)=todo.pop(){
 let s=e.stat(&p)?;let t=e.times_id(s.id)?;
 print!("{}\t{:?}\t{}\t{}\t{}\t{:?}\t{:?}\t{:?}\t{:?}\t",p,s.kind,s.id,s.size,s.revision,t.btime.parts(),t.mtime.parts(),t.ctime.parts(),t.atime.parts());
 if s.kind==Kind::Directory {let mut names:Vec<String>=vec![];loop{let page=e.list(&p,names.last().map(|x|x.as_str()),8)?;if page.is_empty(){break;} names.extend(page);}for x in names.into_iter().rev(){todo.push(format!("{}/{}",p.trim_end_matches('/'),x));}}
 else{let mut off=0;while off<s.size{let read=e.inspect_id(s.id,off,4096)?;assert!(!read.is_empty());off+=read.len() as u64;for b in read{print!("{b:02x}");}}}
 println!();
 }}
 Ok(())
}
