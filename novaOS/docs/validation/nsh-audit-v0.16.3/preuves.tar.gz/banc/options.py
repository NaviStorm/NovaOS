from session import *
arch,s=sys.argv[1],int(sys.argv[2]);stand=W/f'options-{arch}-{s}.raw';shutil.copyfile(W/f'base-{s}.raw',stand)
docs=(R/'novaOS/docs/cli-v0.15.1.md').read_text()
line=next(i for i in docs.split('### Options GNU refusées')[1].splitlines() if i.startswith('| `ls`'))
cases=[('O%02d'%i,'ls '+opt+' alpha.txt',3,'prise en charge',None) for i,opt in enumerate(re.findall(r'`(-[^\s`|]+)',line),1)]
# Les deux colonnes du tableau contiennent chacune une chaîne d’options séparées par des espaces.
cols=line.split('|');opts=(cols[2]+' '+cols[3]).replace('`','').split()
cases=[('O%02d'%i,'ls '+opt+' alpha.txt',3,'prise en charge',None) for i,opt in enumerate(opts,1)]
cases.extend([
 ('Oa01','ls --all',0,'.cache','ls -a'),('Oa02','ls --almost-all',0,'.cache','ls -A'),
 ('Oa03','ls --recursive',0,'profond.txt','ls -R'),('Oa04','ls --directory documents',0,'documents','ls -d documents'),
 ('Oa05','ls --reverse',0,'alpha.txt','ls -r'),('Oa06','ls --classify',0,'documents/','ls -F'),
 ('Oa07','ls -lh /aux/grand',0,'K','ls -l --human-readable /aux/grand'),
 ('Oa08','ls -l --width=24',0,'alpha.txt','ls -lw24'),
 ('Oa09','ls -l1',0,'alpha.txt','ls -1'),('Oa10','ls -1l',0,'fichier','ls -l'),
 ('Oa11','ls -St',0,'alpha.txt','ls -t'),('Oa12','ls -tS',0,'alpha.txt','ls -S'),
 ('Oa13','ls --color=auto',0,'\x1b[34m','ls --color=always'),('Oa14','ls --color=never',0,'alpha.txt','ls'),
 ('Oa15','ls --version',0,'NovaOS 0.16.2',None),('Oa16','ls --help',0,'ls [',None),
 ('T10','cat xyz\t\x7f\x7f\x7falpha.txt',3,'saisie refusée',None),('T11','echo audit-clavier',0,'audit-clavier',None),
 ('T12','\x1b[A',0,'AUDIT_RC=0',None),
 ('K01','ls '+('/'.join(['*']*33)),6,'limite',None),
 ('K02','cat /aux/'+'z'*256,6,'limite',None),('K03',"nsh -c 'x=ab; for i in a b c d e f g h i j k; do x=$x$x; done'",6,'limite',None),
 ('K04','cat ./../../test-nsh/alpha.txt',5,'refusé',None)])
with Terminal(arch,s,stand,'audit-options',test=False) as t:
 t.until(b'nsh> ',150);assert command(t,'cd /test-nsh')[0]==0
 for i,cmd,rc,frag,other in cases:
  observed,out=command(t,cmd);ok=(rc==observed and frag in out)
  if other:
   alt,expected=command(t,other);ok=ok and alt==0 and out==expected
  if i=='T10':ok=observed==0 and out=='alpha A\n'
  row=dict(id=i,cmd=cmd,pre='cwd /test-nsh',want=('Lecture de alpha.txt après Tab sans candidat, trois retours arrière et saisie du nom valide' if i=='T10' else ('Même sortie que '+other if other else frag)),rc_attendu=0 if i=='T10' else rc,rc=observed,out=out,status='PASS' if ok else 'FAIL')
  if i=='T12':row['pre']='Commande précédente echo AUDIT_RC=$? enregistrée par le lecteur de statut'
  with (W/f'options-{arch}-{s}.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
  if not ok:print(row,flush=True)
 t.exit()
