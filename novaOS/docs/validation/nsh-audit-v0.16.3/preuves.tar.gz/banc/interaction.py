from session import *
arch,s=sys.argv[1],int(sys.argv[2]); p=W/f'clavier-{arch}-{s}.raw';shutil.copyfile(W/f'base-{s}.raw',p)
def trace(i,cmd,pre,want,out,ok):
 with (W/f'clavier-{arch}-{s}.jsonl').open('a') as f:f.write(json.dumps(dict(id=i,cmd=cmd,pre=pre,want=want,out=out,status='PASS' if ok else 'FAIL'),ensure_ascii=False)+'\n')
with Terminal(arch,s,p,'audit-clavier',test=False) as t:
 t.until(b'nsh> ',150);assert command(t,'cd /test-nsh')[0]==0
 t.vm.stdin.write(b'touch temoin-tab\t')
 buf=t.until(b'touch temoin-tab');buf+=t.pending;t.pending=b''
 end=time.monotonic()+1
 while time.monotonic()<end:
  if select.select([t.vm.stdout],[],[],max(0,end-time.monotonic()))[0]:
   q=os.read(t.vm.stdout.fileno(),65536);t.log.write(q);buf+=q
 t.vm.stdin.write(b'\n');out=clean(t.until(b'nsh> ')[:-5])
 rc,check=command(t,'test -e temoin-tab')
 trace('K05','touch temoin-tab<Tab> ; attendre 1 s ; Entrée ; test -e temoin-tab','Nom libre, copie neuve','Aucun lancement, publication ou candidat hors capacité',repr(buf)+' ; '+out+' ; test -e = '+str(rc),buf==b'touch temoin-tab' and 'saisie refusée' in out and rc==1)
 for i,cmd,rc,marker in [
  ('K06','cat -Z alpha.txt',3,'invalide'),('K07','cat documents',30,''),
  ('K08','nsh /aux/incorrect.nsh',3,'invalide'),('K09','nsh -c "return 42"',42,''),
  ('K10','cat -- /aux/-tiret',0,'tiret'),('K11','cd /aux; cat -- -tiret',0,'tiret'),
  ('K12','cd /test-nsh; pwd -P',0,'/test-nsh'),('K13','pwd -L',0,'/test-nsh'),
  ('K14','pwd --logical',0,'/test-nsh'),('K15','pwd --physical',0,'/test-nsh')]:
  n,v=command(t,cmd);ok=n==rc and marker in v and (i!='K08' or 'INTERDIT' not in v)
  trace(i,cmd,'Fixture principale, avant K12 cwd /aux' if i=='K12' else 'Session de lecture',f'Code {rc}, '+marker,(v.strip()+' ; code '+str(n)).strip(),ok)
 for i,name in enumerate(['cat','head','tail','more','wc'],16):
  n,v=command(t,name);trace('K'+str(i),name,'Aucun opérande','Refus explicite selon le contrat des fichiers nommés',v.strip()+' ; code '+str(n),n==3 and bool(v.strip()))
  n,v=command(t,name+' /aux/sanslf');raw=t.log.name
  if name not in ('wc',):
   trace('V'+str(i),name+' /aux/sanslf','Le fichier se termine par CD sans LF','Invite lisible sur une ligne distincte après le dernier octet','CDnsh> sans séparation' if v.endswith('CD') else repr(v),not v.endswith('CD'))
 t.exit()
after=snapshot(p,s,'/');before=json.loads((W/f'base-{s}.json').read_text())
assert {k:(v['id'],v['sha256']) for k,v in after.items()}=={k:(v['id'],v['sha256']) for k,v in before.items()}
