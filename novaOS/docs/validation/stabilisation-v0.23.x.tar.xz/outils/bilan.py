from pathlib import Path
import hashlib,json,sys,re
base=Path(sys.argv[1]).resolve()
def sha(f):
 with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def data(p): return json.loads(p.read_text())
tests={}
for arch in ('aarch64','x86_64'):
    arch_dir=base/'livraison'/arch
    files=sorted(arch_dir.glob('*/issue.json'))
    assert len(files)==(10 if arch=='aarch64' else 14)
    assert all(data(f)['ok'] for f in files)
    tests[arch]={'suites':{f.parent.name: data(f)['ok'] for f in files}}
    navigation=sorted((base/'navigation'/arch).glob('*/issue.json'))
    assert len(navigation)==4 and all(data(f)['ok'] for f in navigation)
    tests[arch]['navigation']=[f.parent.name for f in navigation]
    regr=sorted((base/'regressions'/arch).glob('*.json'))
    assert len(regr)==16,(arch,len(regr))
    assert all(data(f)['returncode']==0 for f in regr)
    tests[arch]['regressions']={f.stem:data(f)['returncode'] for f in regr}
    for s in (512,4096):
        hd=data(base/'regressions'/arch/f'head-{s}'/'resultats.json')
        assert len(hd['fichiers_relus_sha256'])==11
        tests[arch][f'head-{s}']={'essais':len(hd['essais']),'fichiers':len(hd['fichiers_relus_sha256'])}
    for profile in ('sdk-example','threads-test'):
        abi=data(base/'abi-finale'/arch/(profile+'.json'))
        assert sha(base/'abi-finale'/arch/abi['journal'])==abi['journal_sha256']
        tests[arch][profile]=abi['elf_sha256']
inter=[]
for phase,n in [('initial',3),('diagnostic',5),('sonde',5),('prefixe-sonde',18),('correction',5),('final',5),('livraison',5),('prefixe-livraison',18)]:
    ns='prefixe' if phase.startswith('prefixe') else 'nsh'
    files=sorted((base/phase/'x86_64').glob(f'{ns}-4096-*/issue.json'))
    assert len(files)==n
    for f in files:
        serial=f.with_name('1-nsh.serial')
        command=serial.read_bytes().decode(errors='replace').partition('nsh> ls src/')[2].partition('nsh> ')[0]
        rc=re.findall(r'\[statut sortie (\d+)\]',command)
        assert len(rc)==1,(f,rc)
        assert data(f)['ok']==(rc==['0'])
        if rc==['0']: assert 'test1.rs' in command and 'lib' in command
        else: assert 'capacité révoquée' in command
        inter.append(dict(etape=phase,essai=f.parent.name,statut=int(rc[0]),sonde=[x for x in command.splitlines() if 'DIAG dir=' in x],serie=serial.relative_to(base).as_posix(),sha256=sha(serial)))
assert all(x['statut']==0 for x in inter if x['etape'] in ('livraison','prefixe-livraison'))
(base/'bilan-qualification.json').write_text(json.dumps(dict(commit='15408d88c9bad4a112d245f378f277bc7e87e7ac',architectures=tests,ls_src=inter),ensure_ascii=False,indent=2)+'\n')
print(len(inter),'observations ls src/; tous les contrôles de livraison sont présents')
