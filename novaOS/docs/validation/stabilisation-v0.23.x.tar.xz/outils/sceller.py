"""Relire chaque original puis chaque membre décompressé des deux archives."""
import gzip, hashlib, io, json, tarfile, sys
from pathlib import Path
source=Path(sys.argv[1]).resolve()
destination=Path(__file__).resolve().parent
public=Path(sys.argv[2]).resolve()
def sha(stream):
    return hashlib.file_digest(stream,"sha256").hexdigest()
def checksum(path):
    with path.open("rb") as f: return sha(f)
def files():
    paths={}
    for path in sorted(source.rglob("*")):
        if path.is_symlink(): raise ValueError(path)
        if path.is_dir(): continue
        if not path.is_file(): raise ValueError(path)
        paths[path.relative_to(source).as_posix()]=checksum(path)
    return paths
def manifest(d):
    return ''.join(f'{digest}  {name}\n' for name,digest in sorted(d.items())).encode()
def append(archive,name,data):
    info=tarfile.TarInfo(name);info.size=len(data)
    archive.addfile(info,io.BytesIO(data))
def pack(path,selected,extras):
    mf=manifest({**selected,**{k:hashlib.sha256(v).hexdigest() for k,v in extras.items()}})
    if path.exists(): raise FileExistsError(path)
    with tarfile.open(path,'w:gz',compresslevel=1) if path.suffix=='.gz' else tarfile.open(path,'w:xz',preset=4) as t:
        t.dereference=True
        for name,digest in selected.items():
            p=source/name
            info=t.gettarinfo(str(p),name)
            info.uid=info.gid=0
            info.uname=info.gname=''
            with p.open("rb") as f: t.addfile(info,f)
        for name,data in extras.items(): append(t,name,data)
        append(t,'SHA256SUMS',mf)
    expected={**selected,**{k:hashlib.sha256(v).hexdigest() for k,v in extras.items()},'SHA256SUMS':hashlib.sha256(mf).hexdigest()}
    with tarfile.open(path,'r|*') as t:
        for item in t:
            assert item.isfile(),item.name
            assert sha(t.extractfile(item))==expected.pop(item.name),item.name
    assert not expected,expected
    return dict(fichier=path.name,preuves=len(selected),membres=len(selected)+len(extras)+1,octets=path.stat().st_size,sha256=checksum(path))
all_files=files()
full=pack(destination/'campagne-complete.tar.gz',all_files,{})
print(full,flush=True)
summary=bytes(json.dumps(full,indent=2)+"\n","utf-8")
keep={}
for name,value in all_files.items():
    path=Path(name)
    if name.startswith(('principal-','origin-')): continue
    if path.suffix in ('.json','.serial','.log','.patch','.py') or name.startswith(('fusion-','environnement','commit-code','abi-finale/','verification-principal','final-aarch64.elf','final-x86_64.elf')):
        keep[name]=value
dist=pack(public,keep,{'inventaire-complet.sha256':manifest(all_files),'archive-complete.json':summary})
print(dist,flush=True)
(destination/'verification.json').write_text(json.dumps([full,dist],indent=2)+'\n')
(destination/'campagne-complete.sha256').write_text(full['sha256']+'  '+full['fichier']+'\n')
public.with_suffix('').with_suffix('.sha256').write_text(dist['sha256']+'  '+dist['fichier']+'\n')
