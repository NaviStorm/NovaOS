"""Conserver les sorties finales des bancs historiques depuis la racine du worktree."""
from pathlib import Path
import hashlib
import shutil
import sys

build = Path("novaOS/build").resolve(strict=True)
destination = Path(sys.argv[1])
destination.mkdir(exist_ok=False)
paths = sorted(
    path for path in build.iterdir()
    if path.is_file() and path.suffix in {".serial", ".log", ".iso", ".json", ".qemu"}
)
for arch in ("aarch64", "x86_64"):
    for sector in (512, 4096):
        directory = build / f"bloc-{arch}-{sector}"
        paths.extend(sorted(path for path in directory.iterdir() if path.suffix in {".serial", ".qemu"}))
def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()
for path in paths:
    target = destination / path.relative_to(build)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    if digest(target) != digest(path):
        raise ValueError(path)
print(f"{len(paths)} sorties de bancs relues après copie")
