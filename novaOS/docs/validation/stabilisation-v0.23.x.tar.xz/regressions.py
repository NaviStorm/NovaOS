from pathlib import Path
import subprocess, os, sys, json, time, shutil
base=Path(__file__).resolve().parent
arch=os.environ['NOVA_ARCH']
root=base/"regressions"/arch
root.mkdir(parents=True,exist_ok=False)
py=[sys.executable,"-B"]
tasks=[("elf",["novaOS/tests/elf.py"]),("processus",["novaOS/tests/cycle_processus.py"]),("ipc",["novaOS/tests/ipc.py","test"]),("ipc-races",["novaOS/tests/ipc.py","races"])]
for sec in ["512","4096"]:
    for script,args in [("temoin-révisions",[str(base/"revisions_p9.py"),arch,sec,str(root/("revisions-"+sec))]),("pipe-head",["novaOS/tests/pipe_head.py",arch,sec,str(root/("head-"+sec))]),("pipe-natif",["novaOS/tests/pipe_natif.py",arch,str(root/("wc-"+sec)),"--sector",sec]),("namespace",["novaOS/tests/namespace.py","--sector",sec]),("fichiers",["novaOS/tests/fichiers.py","--sector",sec]),("cli-p8",["novaOS/tests/cli.py","--sector",sec,"--preuves",str(root/"cli-p8")])]:
        tasks.append((script+"-"+sec,args))
for name,args in tasks:
    print("DEBUT",name,flush=True)
    start=time.time()
    with (root/(name+".log")).open("x") as out:
        res=subprocess.run(py+args,stdout=out,stderr=subprocess.STDOUT)
    (root/(name+".json")).write_text(json.dumps(dict(command=py+args,returncode=res.returncode,seconds=time.time()-start),indent=2)+"\n")
    print("FIN",name,res.returncode,flush=True)
    build=Path("novaOS/build")
    if name.startswith(("namespace-","fichiers-")):
        sec=name.rsplit("-",1)[1]
        src=build/f"bloc-{arch}-{sec}"
        dst=root/(name+"-series")
        dst.mkdir()
        for f in src.glob("*.serial"):
            if f.stat().st_mtime>=start-1:
                shutil.copyfile(f,dst/f.name)
    for f in build.glob("serie-"+arch+"-*.log"):
        if f.stat().st_mtime>=start-1: shutil.copyfile(f,root/f.name)
