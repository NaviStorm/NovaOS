"""Appelle les suites historiques intégrales et garde chaque UART, média et résultat."""
import importlib, json, os, sys, time, traceback
from pathlib import Path
p=Path.cwd()
sys.path.insert(0,str(p/"novaOS/tests"))
import cli
base=Path(__file__).resolve().parent
arch=os.environ["NOVA_ARCH"]
label=sys.argv[1]
real=cli.Terminal
for spec in sys.argv[2:]:
    name,sec,*rest=spec.split(":")
    sector=int(sec)
    out=base/label/arch/("-".join([name,sec,*rest]))
    out.mkdir(parents=True,exist_ok=False)
    counter=0
    class Retenu(real):
        def __init__(self,a,s,image,label,*args,**kw):
            global counter
            counter+=1
            if kw.get("journal") is None:
                kw["journal"]=out/f"{counter}-{label}.serial"
            super().__init__(a,s,image,label,*args,**kw)
    cli.Terminal=Retenu
    m=importlib.import_module(name)
    m.Terminal=Retenu
    start=time.monotonic()
    print("DEBUT",arch,spec,flush=True)
    try:
        if name in ("vi","nsh_scripts"):
            result=m.trial(arch,sector,out)
        elif name=="tmp_prive_cli":
            save=sys.argv
            try:
                sys.argv=[name,"--secteur",sec,"--preuves",str(out/"preuves")]
                result=m.main()
            finally: sys.argv=save
        elif name=="cli_p9":
            result=m.check(arch,sector,out,m.programme_oracle(arch,out))
        else:
            result=m.check(arch,sector,out)
        report=dict(ok=True,result=result)
    except Exception:
        report=dict(ok=False,trace=traceback.format_exc())
    report.update(arch=arch,scenario=name,sector=sector,seconds=time.monotonic()-start)
    (out/"issue.json").write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str)+"\n")
    print("FIN",arch,spec,str(report["ok"]),flush=True)
