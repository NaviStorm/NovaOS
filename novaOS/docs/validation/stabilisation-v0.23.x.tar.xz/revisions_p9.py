"""Exécute les deux clients du profil namespace-write sur la même fixture migrée P9."""
import sys,subprocess,re
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/"novaOS/tests"))
import namespace as ns
from cli import HOST
from bloc import Bench
arch,sec,root=sys.argv[1:]
root=Path(root)
root.mkdir(parents=True,exist_ok=False)
b=Bench(root,arch,int(sec))
ns.image_initiale(b)
old=b.image
_,fs,lv,_=ns.generation(b)
b.image=root/"p9.raw"
with old.open("rb") as src,b.image.open("xb") as dst:
    subprocess.run([HOST,"migrate-content-p9","512",sec,fs,lv],stdin=src,stdout=dst,check=True)
serial=b.run("namespace-write",diagnostic=True)
ns.succes(serial)
assert "NOMS revisions locales et invalidations confirmees" in serial
assert "NOMS seconde session RO cwd=/public" in serial
_,endfs,endlv,_=ns.generation(b)
assert (fs,lv)==(endfs,endlv)
print(arch,sec,"deux clients, révisions et invalidations, P9 remontée et vérifiée")
