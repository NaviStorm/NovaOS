import sys,os,traceback,json
from pathlib import Path
base=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()/'novaOS/tests'))
import cli,vi_pages,nsh_terminal
a=os.environ['NOVA_ARCH']
for s in (512,4096):
 for name,fn in [('terminal',nsh_terminal.trial),('pages',vi_pages.trial)]:
    out=base/'navigation'/a/f'{name}-{s}'
    out.mkdir(parents=True,exist_ok=False)
    class T(cli.Terminal):
        def __init__(self,arch,sec,image,label,*args,**kw):
            kw.setdefault('journal',out/(label+'.serial'))
            super().__init__(arch,sec,image,label,*args,**kw)
    sys.modules[fn.__module__].Terminal=T
    try:
        result=fn(a,s,out,False) if name=='pages' else fn(a,s,out)
        row=dict(ok=True,result=result)
    except Exception:
        row=dict(ok=False,trace=traceback.format_exc())
    (out/'issue.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
    print(name,s,row['ok'],flush=True)
