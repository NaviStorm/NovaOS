"""Exécuter depuis la racine du candidat avec NOVA_KERNEL_ELF vers la sonde mémoire."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import time

sys.path.insert(0, str(Path.cwd() / "novaOS/tests"))
import demarrage

arch = os.environ["NOVA_ARCH"]
preuves = Path(__file__).resolve().parent
def observer(vm, rep, log):
    deadline = time.monotonic() + 90
    raw = b""
    while time.monotonic() < deadline:
        if log.exists():
            raw = log.read_bytes()
            mesures = re.findall(rb"TMP page-reaffectee sentinelle=OK taille=128 phase=(\d) appel=(\d+) autre=11 effets=(\d) ancien=\d+ ticket=\d+ nouveau=DENIED file=0\r?\n", raw)
            if len(mesures) == 2:
                valeurs = [list(map(int, ligne)) for ligne in mesures]
                assert valeurs == [[5, 23, 0], [4, 4, 1]], valeurs
                return valeurs
            if b"Panique du noyau" in raw:
                break
        if vm.poll() is not None:
            break
        time.sleep(.05)
    raise RuntimeError(raw[-2000:].decode(errors="replace"))

with tempfile.TemporaryDirectory(dir=os.environ["NOVAOS_TMPDIR"]) as rep:
    demarrage.BUILD = Path(rep)
    try:
        mesures = demarrage.scenario_vm(arch, "tmp-attentes", observer, "-page-remappee", NOVA_VCPUS="2", NOVA_RAM="256")
    finally:
        journal = demarrage.BUILD / f"serie-{arch}-tmp-attentes-page-remappee.log"
        if journal.is_file():
            shutil.copyfile(journal, preuves / f"serie-{arch}.log")
noyau = Path(os.environ["NOVA_KERNEL_ELF"])
rapport = dict(architecture=arch, vcpu=2, ram_mio=256, mesures=mesures, noyau_sha256=hashlib.sha256(noyau.read_bytes()).hexdigest(), journal_sha256=hashlib.sha256((preuves / f"serie-{arch}.log").read_bytes()).hexdigest())
(preuves / f"resultat-{arch}.json").write_text(json.dumps(rapport, indent=2) + "\n")
