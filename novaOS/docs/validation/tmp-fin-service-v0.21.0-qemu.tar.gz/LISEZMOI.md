# Qualification QEMU de la fin du service tmp

Les sources suivies des noyaux finaux et des sondes ordinaires correspondent au commit `ccb50dde8c90ae5d1f8233cefe78b1530bf58305`. Les dossiers `initial` et `final` contiennent les deux campagnes exécutées. Les conclusions de qualification reposent sur `final`. Les empreintes des noyaux envoyés au lanceur figurent dans `conditions.json`.

Chaque campagne démarre le scénario historique `tmp-attentes`, suivi des cinq fenêtres de retrait, sur AArch64 et x86_64 avec un, deux et quatre vCPU. Chaque fenêtre soumet deux écritures via deux threads avec le même droit. Les deux appels sont effectivement bloqués dans le courtier avant le retrait. Le premier est sélectionné par NEXT selon la fenêtre. L'autre reste en file. Les octets marqués 1 et 2 distinguent ces deux demandes. Le serveur témoin compte chaque effet dans une cellule atomique privée et conserve séparément l’octet appliqué. Le banc lit les deux cellules. Les journaux et les assertions couvrent les étapes suivantes.

| Phase dans le journal | Fenêtre | Statut du premier appel | Nombre d’effets du témoin |
| --- | --- | --- | --- |
| 1 | Avant NEXT | CLOSED (11) | 0 |
| 2 | Après NEXT, avant effet | UNCERTAIN (22) | 0 |
| 3 | Après effet, avant COMPLETE | UNCERTAIN (22) | 1 |
| 4 | Après COMPLETE réussi | OK (0), 128 octets et octet de réponse 0xa7 | 1 |
| 5 | Après COMPLETE en erreur | FULL (23) | 0 |

Chaque seconde demande retourne CLOSED. Chaque nouvel appel avec l’ancien droit ainsi que chaque consultation CAP retournent DENIED. À chaque redémarrage suivant, le serveur obtient WOULD_BLOCK avant admission de nouveaux appels et REVOKED pour un COMPLETE du ticket de l’incarnation précédente. Il répète le contrôle du ticket périmé pendant la nouvelle remise, dans les fenêtres qui vont jusqu’à NEXT. Les phases 4 et 5 imposent au superviseur du banc d’enchaîner le vrai handler COMPLETE et le retrait du processus sous la même garde afin que le client ne consomme pas la réponse entre les deux. Dans les trois autres fenêtres, le service appelle PROCESS_EXIT. Le scénario historique d’annulation et de retrait concomitant reste exercé. Les baux et tickets sont vides à chaque fin. Cette observation d’absence de double effet porte sur les écritures comptées en mémoire du témoin.

## Reproduction des six profils ordinaires

Depuis `novaOS`, définir NOVA_ARCH et les temporaires du projet, construire le noyau par `make ARCH=<architecture> kernel`, puis exécuter `python3 -B tests/tmp_attentes.py`. Le script parcourt les trois configurations de vCPU. NOVA_KERNEL_ELF peut désigner une copie identifiée du noyau.

## Page de réponse réaffectée

Le dossier `memoire` contient le patch de la sonde isolée par rapport aux sources de qualification finales ainsi que son lanceur. Appliquer le patch dans une copie de ces sources. Construire séparément avec Cargo stable, hors ligne et verrouillé, pour aarch64-unknown-none-softfloat et x86_64-unknown-none. Depuis la racine du candidat, définir NOVA_ARCH et NOVA_KERNEL_ELF puis lancer `python3 -B <dossier des preuves>/memoire/lancer.py`. Chaque architecture exécute ce scénario avec deux vCPU.

Le premier thread alloue une page privée avec HEAP_RESIZE et soumet sa trame. Une fois COMPLETE accepté et avant consommation, la sonde réduit le tas, utilise le chemin d’invalidation des attentes, réagrandit le tas à la même adresse virtuelle et écrit une sentinelle de 128 octets. Le client vérifie ces 128 octets après son retour et vérifie aussi que la valeur ABI est zéro. Pour chaque ISA, une erreur de service enregistrée reste FULL, avec zéro effet. Une réponse réussie impossible à copier retourne BAD_ADDRESS (4), avec un seul effet déjà exécuté. Les deux sentinelles restent intactes. L’identité physique du cadre réattribué n’est pas mesurée. Ces deux noyaux sont instrumentés et distincts des noyaux ordinaires.

Tous les invités utilisent un support de démarrage en lecture seule. Les preuves sur fichier P9 et la persistance sur disque relèvent des campagnes de stockage.
