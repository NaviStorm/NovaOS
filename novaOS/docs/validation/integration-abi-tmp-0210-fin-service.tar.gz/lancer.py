"""Lancer depuis le worktree, NOVA_KERNEL_ELF vers le noyau portant la sonde."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time

root = Path.cwd()
sys.path.insert(0, str(root / "novaOS/tests"))
import demarrage

arch = os.environ["NOVA_ARCH"]
noyau = Path(os.environ["NOVA_KERNEL_ELF"])
preuves = Path(__file__).resolve().parent
def controle(vm, repertoire, log):
    debut = re.compile(rb"TMP fin-service NEXT IO STAT ticket=(\d+) COMPLETE absent client bloque")
    fin = re.compile(rb"TMP fin-service serveur_sortie=0 appel_remis=(\d+) nouvel_appel=(\d+) baux=0 tickets=0 client_sortie=0\r?\n")
    deadline = time.monotonic() + 90
    contenu = b""
    while time.monotonic() < deadline:
        if log.exists():
            contenu = log.read_bytes()
            resultat = fin.search(contenu)
            if resultat:
                etape = debut.search(contenu[:resultat.start()])
                assert etape and int(etape[1]) > 0
                return {"ticket": int(etape[1]), "appel_remis": int(resultat[1]),
                        "nouvel_appel": int(resultat[2])}
            if b"Panique du noyau" in contenu:
                break
        if vm.poll() is not None:
            break
        time.sleep(0.05)
    raise RuntimeError(contenu[-2800:].decode(errors="replace"))

with tempfile.TemporaryDirectory(dir=os.environ["NOVAOS_TMPDIR"]) as rep:
    demarrage.BUILD = Path(rep)
    try:
        resultat = demarrage.scenario_vm(arch, "tmp-attentes", controle, "-fin-service",
                                         NOVA_VCPUS="1", NOVA_RAM="256")
    finally:
        journal = demarrage.BUILD / f"serie-{arch}-tmp-attentes-fin-service.log"
        if journal.is_file():
            shutil.copyfile(journal, preuves / f"serie-{arch}.log")

qemu = subprocess.check_output([f"qemu-system-{arch}", "--version"], text=True).splitlines()[0]
resultat.update(architecture=arch, vcpu=1, ram_mio=256, qemu=qemu, accelerateur="TCG",
                disque_de_donnees=False, service="témoin utilisateur", commande_fichier="STAT",
                noyau_sha256=hashlib.sha256(noyau.read_bytes()).hexdigest(),
                noyau_base="23f56d7b2705a00e4e00b21400b4b853afa9a82b",
                journal_sha256=hashlib.sha256((preuves / f"serie-{arch}.log").read_bytes()).hexdigest())
(preuves / f"resultat-{arch}.json").write_text(json.dumps(resultat, indent=2, ensure_ascii=False) + "\n")
