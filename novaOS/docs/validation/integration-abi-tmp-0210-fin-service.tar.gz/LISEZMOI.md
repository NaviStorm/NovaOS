# Fin normale du serveur témoin après remise d’une demande

Sur QEMU 11.1.3 TCG, 1 vCPU et 256 Mio, le client AArch64 et le client x86_64 ont chacun obtenu DENIED (5) pour la demande déjà remise au serveur et DENIED pour le nouvel appel avec la même capacité. L’annulation locale après remise, couverte par le banc historique, est un scénario distinct. Le contrat d’issue incertaine prédit UNCERTAIN (22) pour la première demande. Sur ce parcours la révocation du droit pour les nouveaux appels fonctionne et le statut de la demande en vol diffère de cette prédiction.

Le serveur en espace utilisateur achève CREATE, retire ensuite la demande STAT par NEXT, puis quitte avec le code 0. La sonde vérifie le ticket, l’état bloqué du client et l’absence de COMPLETE. Le client observe le premier retour, soumet une nouvelle trame avec le droit initial et enregistre le second retour. Les assertions interrogent le courtier après la sortie du serveur et vérifient que la file, les baux et le ticket en vol ont disparu. Le client quitte aussi avec le code 0. Aucun disque de données ni service NovaFS n’est attaché. Aucun effet de persistance ou de perte de données n’est mesuré.

## Reproduction

Partir d’une copie isolée des sources de `23f56d7b2705a00e4e00b21400b4b853afa9a82b` dans le répertoire de qualification. Appliquer `sonde.patch` dans cette copie. Le delta concerne uniquement les deux sondes rust du scénario `tmp-attentes`. Les contenus de 343 fichiers de la copie ont été comparés aux objets du commit de départ. Seules ces deux sondes diffèrent.

Pour chaque entrée du tableau, définir `NOVA_ARCH`, `NOVAOS_TMPDIR`, `TMPDIR` et un `CARGO_TARGET_DIR` privé. Dans le dossier `novaOS` de la copie, exécuter `rustup run stable cargo build --offline --locked --release --target <cible>`, avec `RUSTC` issu de `rustup which --toolchain stable rustc`. Depuis la racine du candidat, lancer `python3 -B <preuves>/lancer.py`, avec `NOVA_KERNEL_ELF` égal à `<CARGO_TARGET_DIR>/<cible>/release/novaos`.

| NOVA_ARCH | Cible Rust | Statut après remise | Nouveau statut |
| --- | --- | --- | --- |
| aarch64 | aarch64-unknown-none-softfloat | 5 | 5 |
| x86_64 | x86_64-unknown-none | 5 | 5 |

Chaque JSON conserve le SHA-256 du noyau de sonde et du journal série. Chaque journal série et chaque sortie du banc sont archivés.
