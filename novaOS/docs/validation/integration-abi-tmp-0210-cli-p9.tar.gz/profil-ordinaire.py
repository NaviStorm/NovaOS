"""Banc supplémentaire du profil P9 ordinaire (41). Lancer à la racine du monorepo."""
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path.cwd()
sys.path.insert(0, str(root / "novaOS/tests"))
from cli import Terminal, HOST
from preuves_stockage import empreinte, figer_initiale
from session_cli import fixture_p9

arch = os.environ["NOVA_ARCH"]
sector = int(sys.argv[1])
proofs = Path(sys.argv[2]).resolve()
proofs.mkdir(parents=True, exist_ok=False)
image = proofs / "session.raw"
fixture_p9(image, sector)
figer_initiale(image)
log = proofs / "session.serial"
with tempfile.TemporaryDirectory(dir=os.environ["NOVAOS_TMPDIR"]) as temp:
    oracle = Path(temp) / "oracle"
    subprocess.run(["rustup","run","stable","rustc","--edition=2024","--target","aarch64-apple-darwin",
        "-L","dependency="+str(HOST.parent / "deps"),"--extern","novafs="+str(HOST.parent / "libnovafs.rlib"),
        root / "novaOS/tests/tmp_prive_oracle.rs","-o",oracle],check=True)
    inspect = [oracle,image,str(sector)]
    original = subprocess.check_output(inspect+["catalogue"])
    (proofs / "catalogue-public.txt").write_bytes(original)
    with Terminal(arch, sector, image, "tmp-p9-ordinaire", test=False, journal=log) as tty:
        tty.until(b"nsh> ")
        tty.line("ls -a /",has=["documents","lignes"],absent=[b"NovaOS-tmp-v1",b"registre",b"temoin-ordinaire"])
        tty.line("cat /documents/exemple.txt",has=[b"\r\nNovaOS\r\n"])
        tty.line("touch temoin-ordinaire")
        tty.line("ls -a /",has=[b"\r\ntemoin-ordinaire\r\n"],absent=[b"NovaOS-tmp-v1",b"registre"])
        tty.line("rm temoin-ordinaire")
        tty.line("ls -a /",has=["documents"],absent=[b"NovaOS-tmp-v1",b"registre",b"temoin-ordinaire"])
        tty.exit()
        tty.until(b"SMP arret motif=normal")
    assert b"BLOC bilan mode=41 service=Exit(0)" in log.read_bytes()
    before = empreinte(image)
    checked = subprocess.check_output(inspect+["propre"],text=True).strip()
    assert checked.endswith("sentinelle=3 entrees=1")
    assert original==subprocess.check_output(inspect+["catalogue"]) and before==empreinte(image)
results=dict(isa=arch,secteur=sector,mode=41,commandes=6,oracle=checked,sha256_image=before,
    sha256_catalogue=empreinte(proofs / "catalogue-public.txt"),sha256_serie=empreinte(log),
    kernel_sha256=empreinte(Path(os.environ["NOVA_KERNEL_ELF"])))
(proofs / "resultat.json").write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n")
print(arch,sector,checked)
