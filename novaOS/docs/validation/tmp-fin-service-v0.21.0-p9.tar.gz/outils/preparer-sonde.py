"""Copie de construction confinée et delta complet des quatre sondes ; lancer depuis la racine."""
from pathlib import Path
import hashlib, shutil, json, difflib
ROOT=Path.cwd()
BASE=Path(__file__).resolve().parents[1]
src=BASE/"labo"/"sources"
src.mkdir()
inputs={}
parts=["novaOS/.cargo","novaOS/Cargo.toml","novaOS/Cargo.lock","novaOS/rust-toolchain.toml","novaOS/abi","novaOS/kernel","novaOS/libs","novaOS/user","components","novaFS/Cargo.toml","novaFS/Cargo.lock","novaFS/src"]
ignore=shutil.ignore_patterns(".git","target","build","__pycache__",".DS_Store")
for name in parts:
    path=ROOT/name
    dest=src/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    if path.is_dir(): shutil.copytree(path,dest,ignore=ignore)
    else: shutil.copy2(path,dest)
for path in sorted(src.rglob("*")):
    if path.is_file():
        relative=path.relative_to(src)
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest==hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
        inputs[str(relative)]=digest
patch=[]
def update(name,pairs):
    t=src/name
    before=t.read_text()
    updated=before
    for a,b in pairs:
        assert updated.count(a)==1,(name,a)
        updated=updated.replace(a,b)
    t.write_text(updated)
    patch.extend(difflib.unified_diff(before.splitlines(True),updated.splitlines(True),fromfile="a/"+name,tofile="b/"+name))
update("novaOS/user/novafs/qualification.rs",[
("use core::cell::Cell;","use core::cell::Cell;\npub static LAB_SYNC: core::sync::atomic::AtomicBool = core::sync::atomic::AtomicBool::new(false);"),
("pub fn before_flush(&self) {","pub fn before_flush(&self) {\n        if LAB_SYNC.load(core::sync::atomic::Ordering::Relaxed) { marker(b\"P9 LAB FLUSH submit\"); }"),
("pub fn after_flush(&self) {","pub fn after_flush(&self) {\n        if LAB_SYNC.load(core::sync::atomic::Ordering::Relaxed) { marker(b\"P9 LAB FLUSH ack\"); }")])
# A et B sont des données fictives. Elles choisissent l'injection sans modifier une trame.
update("novaOS/user/novafs/files/temporary.rs",[
("struct Private {", """static LAB_BYTE: core::sync::atomic::AtomicU8 = core::sync::atomic::AtomicU8::new(0);
fn lab_generation(g: u64) {
    let mut msg = *b"P9 LAB generation=0000000000000000";
    let start=msg.len()-16;
    for i in 0..16 { msg[start+i] = b"0123456789abcdef"[((g >> (60-4*i)) & 15) as usize]; }
    log(&msg);
}
struct Private {"""),
("            let result = if kind == wire::REMOVE {","""            if kind == wire::IO && q[1] == w::WRITE && w::length(q) == 1 {
                LAB_BYTE.store(q[w::PAYLOAD], core::sync::atomic::Ordering::Relaxed);
            }
            let lab = kind == wire::IO && q[1] == w::SYNC
                && matches!(LAB_BYTE.load(core::sync::atomic::Ordering::Relaxed), b'A' | b'B');
            if lab {
                lab_generation(self.fs.as_ref().unwrap().generation());
                if LAB_BYTE.load(core::sync::atomic::Ordering::Relaxed)==b'A' {
                    log(b"P9 LAB NEXT fin avant execution");
                    rt::exit(90);
                }
                log(b"P9 LAB NEXT execution");
                crate::qualification::LAB_SYNC.store(true, core::sync::atomic::Ordering::Relaxed);
            }
            let result = if kind == wire::REMOVE {"""),
("            let status = result.err().unwrap_or(rt::OK);","""            if lab {
                if result.is_err() { rt::exit(91); }
                log(b"P9 LAB execution reussie fin avant COMPLETE");
                rt::exit(90);
            }
            let status = result.err().unwrap_or(rt::OK);""")])
update("novaOS/user/tmp_sample.rs",[
("    let data = if mode == 1", """    if matches!(mode, 81 | 82) {
        stage_byte(own, h, if mode==81 { b'A' } else { b'B' });
        check(send(own,&mut fs::frame(fs::SYNC,1,h)),fs::UNCERTAIN,84);
        // La seconde demande emploie le même ancien droit, contrôle observable après la mort.
        check(send(own,&mut fs::frame(fs::STAT,1,h)),rt::DENIED,85);
        rt::exit(0)
    }
    let data = if mode == 1""")])
update("novaOS/kernel/src/sched/process/ipc/tmp_probe.rs",[
("    if scenario == b\"tmp-reprise\" {","""    if matches!(scenario, b"tmp-coupure" | b"tmp-test") {
        let mode = if scenario == b"tmp-coupure" { 81 } else { 82 };
        let client = launch(mode);
        assert_eq!(client.join(), Outcome::Exit(0));
        hal::log(format_args!("P9 LAB client SYNC=UNCERTAIN appel_suivant=DENIED mode={mode}"));
        return;
    }
    if scenario == b"tmp-reprise" {""")])
(BASE/"outils"/"sonde.patch").write_text("".join(patch))
(BASE/"outils"/"source-sha256.json").write_text(json.dumps(inputs,indent=2)+"\n")
(BASE/"outils"/"sonde-sha256.json").write_text(json.dumps({k:hashlib.sha256((src/k).read_bytes()).hexdigest() for k in inputs if inputs[k]!=hashlib.sha256((src/k).read_bytes()).hexdigest()},indent=2)+"\n")
