use novafs::{Device, Engine, Mode, Kind, codec::Anchor, device::FileImage};
use std::{env, fs::File, error::Error};

fn main() -> Result<(), Box<dyn Error>> {
    let a: Vec<_> = env::args().collect();
    let file=File::open(&a[1])?;
    let disk=FileImage::from_file(file.try_clone()?,file.metadata()?.len()/4096,a[2].parse()?)?;
    let before:u64=a[3].parse()?;
    let commits:u64=a[4].parse()?;
    assert!(commits<=1);
    let first=Anchor::decode(&disk.read(0)?,0)?;
    let second=Anchor::decode(&disk.read(1)?,1)?;
    assert_eq!(first.ids,second.ids);
    let mut generations=[first.manifest.birth,second.manifest.birth];
    generations.sort();
    assert_eq!(generations,[before+commits-1,before+commits]);
    let fs=Engine::mount_current(disk,first.ids,Mode::ReadOnly)?;
    fs.verify()?;
    assert!(fs.atime_policy().is_some());
    assert_eq!(fs.generation(),before+commits);
    let store=fs.lookup_at(fs.root_id(),"\x1fNovaOS-tmp-v1")?.id;
    let entries=fs.inspect_dir(store,None,32)?;
    assert_eq!(entries.len(),5);
    assert!(entries.iter().any(|s|s=="registre"));
    let roots:Vec<_>=entries.iter().filter(|s|s.starts_with('t')).collect();
    assert_eq!(roots.len(),2);
    let mut files=vec![];
    for root in roots {
        assert!(entries.contains(&format!("r{}",&root[1..])));
        let tmp=fs.lookup_at(store,root)?.id;
        for n in fs.inspect_dir(tmp,None,32)? {
            assert_eq!(n,"commun");
            let stat=fs.lookup_at(tmp,&n)?;
            assert_eq!(stat.kind,Kind::File);
            assert_eq!(stat.size,commits);
            let bytes=fs.inspect_id(stat.id,0,2)?;
            assert_eq!(bytes.as_slice(),if commits==1 {b"B".as_slice()} else {b"".as_slice()});
            files.push((stat.id,bytes));
        }
    }
    assert_eq!(files.len(),1);
    println!("avant={before} apres={} ancres={generations:?} commits={commits} fichier={} octets={:?} racines=2 fs_verify=OK",fs.generation(),files[0].0,files[0].1);
    Ok(())
}
