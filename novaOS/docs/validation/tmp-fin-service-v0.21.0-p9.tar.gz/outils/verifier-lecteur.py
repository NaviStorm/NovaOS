"""Lecture stricte du marqueur BootID dans les journaux SMP intégraux."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/"novaOS/tests"))
from tmp_prive import identite_serie
d=Path(__file__).resolve().parent/"cas-invite"
first=b"4407c59448d290474b3f8e93a0cbd235"
second=b"3d75ac172b9f896353ff35c8ed2fba24"
prefix="TMP démarrage ".encode()
cases=[("flux-réel-invite-contiguë",(d/"source.serial").read_bytes(),(first,True)),("flux-réel-invite-entrelacée",(d/"fragmentee.serial").read_bytes(),(second,True)),("normal",prefix+first+b"\n",(first,False))]
for name,line in [("double-invite",first+b"nsh> nsh> "),("court",first[:-1]),("long",first+b"4"),("invalide",first[:-1]+b"z"),("étranger",b"uid> "+first),("ordre",first+b"snh> "),("invite-incomplète",first+b"nsh>")]:
    cases.append((name,prefix+line+b"\r\n",(None,False)))
cases.extend([("pas-de-fin-de-ligne",prefix+first,(None,False)),("fausse-amorce",b"TMP="+first+b"\r\n",(None,False))])
rows={}
for name,raw,expected in cases:
    ident,prompt=identite_serie(raw)
    assert (ident,prompt)==expected,(name,ident,prompt)
    rows[name]={"identite":ident.decode() if ident else None,"invite":prompt}
(d/"lecteur-complet.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2)+"\n")
