set -eu
export NOVA_ARCH="$1"
export NOVA_KERNEL_ELF="$PWD/novaOS/build/qualification-fin-service-p9-final-0210/noyaux/$1.elf"
preuves="$PWD/novaOS/build/qualification-fin-service-p9-final-0210"
for secteur in 512 4096; do
  for cpu in 1 2 4; do
    etape="$preuves/qemu/$NOVA_ARCH-$secteur-$cpu"
    python3 -B novaOS/tests/tmp_prive.py --secteur "$secteur" --vcpus "$cpu" --preuves "$etape" >"$etape.log" 2>&1
  done
  etape="$preuves/cli-qualification/$NOVA_ARCH-$secteur"
  mkdir -p "$preuves/cli-qualification" "$preuves/cli-ordinaire" "$preuves/refus" "$preuves/p8"
  python3 -B novaOS/tests/tmp_prive_cli.py --secteur "$secteur" --preuves "$etape" >"$etape.log" 2>&1
  etape="$preuves/cli-ordinaire/$NOVA_ARCH-$secteur"
  python3 -B "$preuves/outils/profil-ordinaire.py" "$secteur" "$etape" >"$etape.log" 2>&1
  etape="$preuves/refus/$NOVA_ARCH-$secteur"
  if [ "$secteur" = 4096 ]; then
    python3 -B novaOS/tests/tmp_prive_refus.py --production --secteur "$secteur" --preuves "$etape" >"$etape.log" 2>&1
  else
    python3 -B novaOS/tests/tmp_prive_refus.py --secteur "$secteur" --preuves "$etape" >"$etape.log" 2>&1
  fi
  python3 -B novaOS/tests/cli.py --sector "$secteur" --preuves "$preuves/p8" >"$preuves/p8/$NOVA_ARCH-$secteur.log" 2>&1
done
