"""Sonde de mort du service P9 dans une copie privée. Aucune réexécution de la demande."""
import os, subprocess, sys, re, json, time, hashlib, gzip, signal, tempfile,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/"novaOS/tests"))
from tmp_prive import capture, command, fixture_p9
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def preserve(raw,path):
    with raw.open("rb") as source,gzip.open(path,"xb") as dest: shutil.copyfileobj(source,dest)
    with gzip.open(path,"rb") as check: assert hashlib.file_digest(check,"sha256").hexdigest()==sha(raw)
arch=os.environ["NOVA_ARCH"]
target={"aarch64":"aarch64-unknown-none-softfloat","x86_64":"x86_64-unknown-none"}[arch]
snapshot=BASE/"labo"/("target-"+arch)/target/"release/novaos"
ordinary=BASE/"noyaux"/(arch+".elf")
proofs=BASE/"mutations"/arch
proofs.mkdir(parents=True,exist_ok=False)
e=BASE/"outils"
oracle=e/"oracle-sonde"
public=e/"oracle-public"
env={**os.environ,"NOVA_VCPUS":"1","NOVA_RAM":"256"}
def iso(scenario, path, elf):
    subprocess.run(["sh",ROOT/"novaOS/scripts/iso.sh",scenario,path],check=True,env={**env,"NOVA_KERNEL_ELF":str(elf)},stdout=subprocess.DEVNULL)
with tempfile.TemporaryDirectory(dir=os.environ["NOVAOS_TMPDIR"]) as temp:
    work=Path(temp)
    restarter=work/"reprise.iso"
    iso("tmp-reprise",restarter,ordinary)
    for sector in (512,4096):
        base=work/f"base-{sector}.raw"
        fixture_p9(base,sector)
        baseline=subprocess.check_output([public,base,str(sector),"catalogue"])
        (proofs/f"{sector}-catalogue.txt").write_bytes(baseline)
        preserve(base,proofs/f"{sector}-initiale.raw.gz")
        for scenario,commits,mode in [("tmp-coupure",0,81),("tmp-test",1,82)]:
            case=f"{sector}-{commits}"
            local=proofs/case
            local.mkdir()
            disk=work/(case+".raw")
            shutil.copyfile(base,disk)
            log=local/"injection.serial"
            trace=local/"qemu-bloc.log"
            medium=work/(case+".iso")
            iso(scenario,medium,snapshot)
            controls=["-display","none","-monitor","none","-serial","file:"+str(log),"-trace","enable=virtio_blk_handle_*,file="+str(trace)]
            with subprocess.Popen(command(arch,sector,disk,controls=controls),env={**env,"NOVA_ISO":str(medium)}) as vm:
                limit=time.monotonic()+120
                done=f"P9 LAB client SYNC=UNCERTAIN appel_suivant=DENIED mode={mode}".encode()
                try:
                    while time.monotonic()<limit:
                        series=log.read_bytes() if log.exists() else b""
                        if done in series: break
                        if vm.poll() is not None or b"Panique du noyau" in series: break
                        time.sleep(.03)
                    assert done in series,series[-2200:]
                finally:
                    if vm.poll() is None: vm.kill()
                    vm.wait(timeout=10)
            original=log.read_bytes()
            assert original.count(done)==1 and b"Panique du noyau" not in original
            before,=re.findall(rb"P9 LAB generation=([0-9a-f]{16})",original)
            steps=re.findall(rb"P9 LAB (?:FLUSH (?:submit|ack)|NEXT [^\r\n]*|execution reussie fin avant COMPLETE)",original)
            wanted=[b"P9 LAB NEXT fin avant execution"] if not commits else [b"P9 LAB NEXT execution",b"P9 LAB FLUSH submit",b"P9 LAB FLUSH ack",b"P9 LAB FLUSH submit",b"P9 LAB FLUSH ack",b"P9 LAB execution reussie fin avant COMPLETE"]
            assert steps==wanted,(steps,wanted)
            assert b"virtio_blk_handle_write" in trace.read_bytes()
            before=int(before,16)
            initial=sha(disk)
            verified=subprocess.check_output([oracle,disk,str(sector),str(before),str(commits)],text=True).strip()
            assert baseline==subprocess.check_output([public,disk,str(sector),"catalogue"])
            assert sha(disk)==initial
            preserve(disk,local/"apres-mort.raw.gz")
            recov=local/"reprise.serial"
            capture(arch,sector,disk,restarter,"tmp-reprise",recov,1)
            assert b"TMP reprise orphelins retires" in recov.read_bytes()
            saved=sha(disk)
            result=subprocess.check_output([public,disk,str(sector),"propre"],text=True).strip()
            assert baseline==subprocess.check_output([public,disk,str(sector),"catalogue"]) and sha(disk)==saved
            preserve(disk,local/"apres-reprise.raw.gz")
            row=dict(arch=arch,sector=sector,vcpu=1,mode=mode,sha256_sonde=sha(snapshot),sha256_reprise=sha(ordinary),generation_avant=before,commits=commits,client="UNCERTAIN",ancien_droit="DENIED",barrieres_acquittees=steps.count(b"P9 LAB FLUSH ack"),oracle=verified,reprise=result,disque_apres_mort=initial,disque_apres_reprise=saved)
            (local/"resultat.json").write_text(json.dumps(row,indent=2,ensure_ascii=False)+"\n")
            print(arch,sector,mode,verified,result,flush=True)
