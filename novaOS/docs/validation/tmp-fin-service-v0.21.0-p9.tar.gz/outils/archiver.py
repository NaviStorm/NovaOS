"""Valider chaque résultat, construire une archive autonome des preuves et la relire."""
from pathlib import Path
import json, hashlib,gzip,tarfile,sys,re,subprocess, platform
BASE=Path(__file__).resolve().parents[1]
repo=Path.cwd()
sys.path.insert(0,str(repo/"novaOS/tests"))
from tmp_prive import identite_serie
def sha(path):
    with path.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def payload(path):
    with gzip.open(path,"rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def doc(p): return json.loads(p.read_text())
def dump(p,obj): p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
proofs={}
for root in ["qemu","cli-qualification","cli-ordinaire","p8","refus","outils","mutations","diagnostic"]:
    for path in (BASE/root).rglob("*"):
        if path.is_file() and path.suffix!=".iso" and path.name not in ("controle-p9.py","oracle-sonde","oracle-public"):
            proofs[str(path.relative_to(BASE))]=path
for role in ["tmp_prive","tmp_prive_refus","tmp_prive_cli","cli"]:
    proofs[f"banc/{role}.py"]=repo/"novaOS/tests"/(role+".py")
proofs["banc/tmp_prive_oracle.rs"]=repo/"novaOS/tests/tmp_prive_oracle.rs"
expected={"aarch64":"4518c1f86da7d20ad35feabb5c7aaa41dc759c8d110ba391ba3ba55d8a43158a","x86_64":"03401cccdf1bad3e30c5b1084e8ea7a725873d4b1ad6d2cf0728c2973a738bb2"}
idset=set()
joined=[]
for a,k in expected.items():
    assert sha(BASE/"noyaux"/(a+".elf"))==k
    lab=next((BASE/"labo"/("target-"+a)).glob("*/release/novaos"))
    proofs[f"sonde/{a}.elf"]=lab
    proofs[f"sonde/{a}-execution.log"]=BASE/"labo"/(a+".log")
    for s in (512,4096):
        for c in (1,2,4):
            d=BASE/"qemu"/f"{a}-{s}-{c}"
            rows=doc(d/"resultats.json")
            assert len(rows)==4
            for i,(scenario,r) in enumerate(zip(("tmp-test","tmp-reprise","tmp-coupure","tmp-reprise"),rows,strict=True)):
                assert r["noyau_sha256"]==k and (r["architecture"],r["secteur"],r["vcpus"],r["scenario"])==(a,s,c,scenario)
                raw=d/f"{i}-{scenario}.raw.gz"; log=d/f"{i}-{scenario}.serial"
                assert r["disque_sha256"]==payload(raw) and r["journal_sha256"]==sha(log)
                assert sha(d/"catalogue-public.txt")==r["catalogue_sha256"]
                series=log.read_bytes()
                boot,prompt=identite_serie(series)
                assert boot and boot.decode()==r["boot"] and boot not in idset
                idset.add(boot)
                mask=hex((1<<c)-1)
                if i==2:
                    assert "entrees=5" in r["oracle"] and b"TMP coupure" in series
                else:
                    assert f"attendus={mask} en_ligne={mask} ack={mask} absents=0x0 muets=0x0".encode() in series and "entrees=1" in r["oracle"]
                if i==3: assert b"TMP reprise orphelins retires" in series
                joined.append(dict(architecture=a,secteur=s,cpu=c,sequence=i,identite=r["boot"],invite_dans_identite=prompt))
            assert [(r["instance"],r["generation"]) for r in rows[::2]]==[(r["instance"],r["generation"]) for r in rows[1::2]]
        for flavor,mode in [("cli-ordinaire",41),("cli-qualification",42),("p8",None)]:
            d=BASE/flavor/f"{a}-{s}"; r=doc(d/"resultat.json")
            image="volume.raw" if mode is None else "session.raw"
            assert r["sha256_image"]==sha(d/image) and doc(d/"images.json")["initiale_sha256"]==sha(d/"initiale.raw")
            for meta in d.glob("*.vm.json"):
                cfg=doc(meta)
                assert cfg["elf_sha256"]==k and cfg["architecture"]==a and cfg["octets_secteur"]==s
                assert cfg["iso_sha256"]==sha(d/meta.name.replace(".vm.json",".iso"))
            if mode is None:
                assert r["generations"]==[40,43,44] and len(r["journaux"])==4 and len(list(d.glob("*.vm.json")))==4
                for j,v in r["journaux"].items(): assert sha(d/j)==v
            else:
                assert len(list(d.glob("*.vm.json")))==1 and f"BLOC bilan mode={mode} service=Exit(0)".encode() in (d/"session.serial").read_bytes()
                assert r["sha256_serie"]==sha(d/"session.serial") and r["oracle"].endswith("sentinelle=3 entrees=1")
        d=BASE/"refus"/f"{a}-{s}"
        refus=doc(d/"resultats.json")
        assert {r["cas"] for r in refus}=={"sans-bootid","volume-invalide","p8-sur-lanceur-p9","p9-sur-lanceur-p8"} and len(refus)==4
        for r in refus:
            name=r["cas"]
            assert r["ecritures_qemu"]==0 and sha(d/(name+".serial"))==r["trace"] and sha(d/(name+".bloc"))==r["bloc_sha256"] and payload(d/(name+".initiale.raw.gz"))==r["image_avant_apres"]
        for n in (0,1):
            u=BASE/"mutations"/a/f"{s}-{n}"; r=doc(u/"resultat.json")
            assert r["sha256_sonde"]==sha(lab) and r["sha256_reprise"]==k
            assert r["generation_avant"]==51 and r["commits"]==n and r["barrieres_acquittees"]==2*n
            assert payload(u/"apres-mort.raw.gz")==r["disque_apres_mort"] and payload(u/"apres-reprise.raw.gz")==r["disque_apres_reprise"]
assert len(joined)==len(idset)==48
shared=repo/"novaOS/docs/validation"
historical=shared/"integration-abi-tmp-v0.21.0-p9.tar.gz"
historical_digest=sha(historical)
assert historical_digest=="58c2caf755f43e720fe4e7b054299152b626f1a6db16aa291a0e1fbb60e20135"
base="23f56d7b2705a00e4e00b21400b4b853afa9a82b"
source="ccb50dde8c90ae5d1f8233cefe78b1530bf58305"
storage=["novaFS","novaOS/user/novafs","novaOS/tests/tmp_prive_stockage.rs","novaOS/tests/tmp_prive_stockage.sh"]
assert not subprocess.check_output(["git","diff","--name-only",base,source,"--",*storage])
cuts=other=0
with tarfile.open(historical,"r:gz") as t:
    hashes=json.load(t.extractfile("SHA256.json"))
    for a in expected:
        name=f"stockage/{a}/stockage.log"
        data=t.extractfile(name).read()
        assert hashlib.sha256(data).hexdigest()==hashes[name]
        cuts+=sum(map(int,re.findall(rb"injections_F1_F2=(\d+)",data)))
        other+=sum(map(int,re.findall(rb"pr.parations_interrompues=(\d+)",data.decode().encode("latin1"))))
        for s in (512,4096):
            n=f"stockage/{a}/image-{a}-{s}.raw"
            assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==hashes[n]
assert (cuts,other)==(312,8)
assert len(doc(BASE/"outils/cas-invite/lecteur-complet.json"))==12
snapshot=shared/"tmp-fin-service-v0.21.0-instances.tar.gz"
with tarfile.open(snapshot,"r:gz") as t:
    for a,k in expected.items(): assert hashlib.sha256(t.extractfile(f"{a}/noyau.elf").read()).hexdigest()==k
report={"sources_invitees":source,"source_du_lecteur_bootid":sha(repo/"novaOS/tests/tmp_prive.py"),"noyaux_ordinaires":expected,"archive_noyaux":snapshot.name,"sha256_archive_noyaux":sha(snapshot),"p9_invite":48,"p9_cli_production":4,"p9_cli_qualification":4,"p8_cli":16,"admissions_refusees_sans_ecriture":16,"mutations_reelles_sonde":8,"reprises_apres_mort_noyau_ordinaire":8,"profils_qemu":["AArch64","x86_64"],"duree_modele":"TCG, 256 Mio, disque VirtIO raw ; arrêt du processus QEMU pour les coupures","stockage_darwin":{"grille_reutilisee":historical.name,"sha256":historical_digest,"base":base,"sources_verifiees":storage,"injections_F1_F2":cuts,"autres_coupures":other},"observations":joined}
res=BASE/"bilan.json"
dump(res,report);proofs["bilan.json"]=res
manifest={name:sha(path) for name,path in sorted(proofs.items())}
mp=BASE/"SHA256.json";dump(mp,manifest);proofs["SHA256.json"]=mp
archive=shared/"tmp-fin-service-v0.21.0-p9.tar.gz"
assert not archive.exists()
with tarfile.open(archive,"x:gz",compresslevel=6) as t:
    for name,path in sorted(proofs.items()): t.add(path,arcname=name,recursive=False)
with tarfile.open(archive,"r:gz") as t:
    assert set(t.getnames())==set(proofs)
    for name,path in proofs.items():
        assert hashlib.file_digest(t.extractfile(name),"sha256").hexdigest()==sha(path)
print(archive,archive.stat().st_size,len(proofs),sha(archive),flush=True)
