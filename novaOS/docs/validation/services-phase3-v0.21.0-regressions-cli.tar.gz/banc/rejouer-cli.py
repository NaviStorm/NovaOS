"""Rejouer les bancs publiés sur un noyau gelé. Les ISO et UART restent propres à chaque VM."""
from pathlib import Path
import hashlib, json, os, platform, shutil, subprocess, sys, time, traceback
ROOT=Path(__file__).resolve().parents[3]
SOURCES=ROOT/'novaOS'
sys.path.insert(0,str(SOURCES/'tests'))
sys.path.insert(0,str(SOURCES/'scripts'))
import cli, nsh, nsh_scripts, vi, tmp_prive_cli
ARCH,KERNEL,SHA,RUN=sys.argv[1:5]
EXERCISES=sys.argv[5:] or ['p8','vfs-p9','vi','nsh-scripts','nsh']
assert ARCH in ('x86_64','aarch64') and all(x in ('p8','vfs-p9','vi','nsh-scripts','nsh') for x in EXERCISES)
work=Path(os.environ['NOVAOS_TMPDIR']).resolve()
assert str(work).endswith('/OS-worktrees/tmp')
assert os.environ['TMPDIR']==str(work)+'/'
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
kernel=Path(KERNEL).resolve(strict=True)
assert digest(kernel)==SHA
os.environ.update(NOVA_ARCH=ARCH,NOVA_VCPUS='1',NOVA_KERNEL_ELF=str(kernel),PYTHONDONTWRITEBYTECODE='1')
qemu=subprocess.check_output([f'qemu-system-{ARCH}','--version'],text=True).splitlines()[0]
root=SOURCES/'build/qualification-services-0210/reg-cli'/RUN/ARCH
root.mkdir(exist_ok=True,parents=True)
serial_dir=None
class Terminal(cli.Terminal):
    def __init__(self, arch, sec, image, label, *args, **options):
        assert arch==ARCH
        if options.get('journal') is None:options['journal']=serial_dir/(label+'.serial')
        super().__init__(arch,sec,image,label,*args,**options)
        assert self.archive.is_relative_to(root) and self.archive.name.endswith('.serial')
cli.Terminal=nsh.Terminal=nsh_scripts.Terminal=vi.Terminal=tmp_prive_cli.Terminal=Terminal
failed_cases=[]
for exercise in EXERCISES:
  for sector in (512,4096):
    case=root/(exercise+'-'+str(sector));case.mkdir(exist_ok=False)
    serial_dir=case
    done=dict(architecture=ARCH,secteur=sector,profil=exercise,vcpus=1,noyau_sha256=SHA,qemu=qemu)
    started=time.monotonic()
    try:
      if exercise=='p8':
        index=cli.check(ARCH,sector,case,preuves=True)
        done['resultat']=json.loads((case/'resultat.json').read_text())
      elif exercise=='vfs-p9':
        folder=case/'volume'
        sys.argv=['tmp_prive_cli.py','--secteur',str(sector),'--preuves',str(folder)]
        tmp_prive_cli.main()
        done['resultat']=json.loads((folder/'resultat.json').read_text())
      elif exercise=='nsh':done['resultat']=nsh.check(ARCH,sector,case)
      elif exercise=='nsh-scripts':done['resultat']=nsh_scripts.trial(ARCH,sector,case)
      elif exercise=='vi':done['resultat']=vi.trial(ARCH,sector,case)
      done['statut']='réussi'
    except Exception as error:
      done['statut']='échec'
      failed_cases.append(f'{exercise}/{sector}')
      done['erreur']=str(error)
      with (case/'traceback.txt').open('x') as f:traceback.print_exc(file=f)
    assert digest(kernel)==SHA
    done['secondes']=round(time.monotonic()-started,3)
    done['journaux']={str(f.relative_to(case)):digest(f) for f in sorted(case.rglob('*.serial'))}
    done['iso']={str(f.relative_to(case)):digest(f) for f in sorted(case.rglob('*.iso'))}
    done['image']={str(f.relative_to(case)):digest(f) for f in sorted(case.rglob('*.raw'))}
    assert done['journaux'] and done['iso'] or done['statut']=='échec'
    (case/'qualification.json').write_text(json.dumps(done,ensure_ascii=False,indent=2)+'\n')
    print(ARCH,sector,exercise,done['statut'],done.get('erreur','')[:120],flush=True)
if failed_cases:
    sys.exit('Échecs conservés : '+', '.join(failed_cases))
