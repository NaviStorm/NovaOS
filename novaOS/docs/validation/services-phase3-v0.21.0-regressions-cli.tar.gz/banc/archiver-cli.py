"""Vérifie les sessions et les octets avant de produire l'archive de qualification."""
from pathlib import Path
import collections,gzip,hashlib,io,json,subprocess,sys,tarfile
root=Path(__file__).resolve().parents[3]
build=root/'novaOS/build/qualification-services-0210'
campaign=build/'reg-cli'/sys.argv[1]
dest=Path(sys.argv[2]).resolve()
assert not dest.exists()
def h(data):return hashlib.sha256(data).hexdigest()
def fhash(f):
    with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
files={}
counts=collections.Counter()
cases=[]
boot=0
isos=0
for p in sorted(campaign.rglob('qualification.json')):
    row=json.loads(p.read_text())
    case=p.parent
    assert row['statut']=='réussi', (p,row)
    for group in ('journaux','iso','image'):
        for rel,signature in row[group].items():
            path=case/rel
            assert path.is_file() and signature==fhash(path)
            if group=='iso':
                actual=subprocess.check_output(['/usr/bin/tar','-xOf',str(path),'boot/novaos.elf'])
                assert h(actual)==row['noyau_sha256']
                isos+=1
    for md in case.rglob('*.vm.json'):
        r=json.loads(md.read_text());stem=md.name.removesuffix('.vm.json')
        assert r['elf_sha256']==row['noyau_sha256'] and r['vcpu']==1 and r['octets_secteur']==row['secteur']
        assert fhash(md.with_name(stem+'.iso'))==r['iso_sha256']
        assert md.with_name(stem+'.serial').is_file()
        boot+=1
    counts[row['profil']]+=len(row['journaux'])
    cases.append({k:v for k,v in row.items() if k not in ('journaux','iso','image')})
    for f in case.rglob('*'):
        if f.is_file() and f.suffix in ('.serial','.json','.raw'):
            files[f.relative_to(campaign).as_posix()]=f
assert len(cases)==20 and boot==44 and isos==44,(len(cases),boot,isos)
assert set(counts)=={'p8','vfs-p9','vi','nsh-scripts','nsh'}
for name in ('aarch64','x86_64'):
    files[f'{name}.log']=campaign.parent/(name+'-'+campaign.name+'.log')
files['banc/rejouer-cli.py']=build/'rejouer-cli.py'
files['banc/archiver-cli.py']=Path(__file__)
for p in ('tests/cli.py','tests/nsh.py','tests/nsh_scripts.py','tests/vi.py','tests/tmp_prive_cli.py','tests/tmp_prive_oracle.rs','scripts/session_cli.py','tests/preuves_stockage.py'):
    files['banc/'+p]=root/'novaOS'/p
scripts_bash=[]
if campaign.name=='livraison':
    for p in sorted(campaign.glob('*/nsh-scripts-*/qualification.json')):
        row=json.loads(p.read_text())
        uart=(p.parent/'scripts.serial').read_bytes()
        expected=('\r\n'.join(row['resultat']['bash'])+'\r\n').encode()
        assert expected in uart
        assert b'SVC stockage INFO disponible' not in uart
        assert b'SVC tmp prive ordinaire refuse et delegation verifiee' not in uart
        scripts_bash.append(dict(arch=row['architecture'],secteur=row['secteur'],sha256_uart=h(uart),sha256_bloc_bash_uart=h(expected)))
    assert len(scripts_bash)==4
summary={'bash_sortie_contigue':scripts_bash,'vm':boot,'iso_elf_relus':isos,'cas':len(cases),'sessions_par_banc':dict(counts),'resultats':cases}
bilan=campaign/'bilan.json'
assert not bilan.exists()
bilan.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
files['bilan.json']=bilan
sources={name:f.read_bytes() for name,f in files.items()}
sha={name:h(data) for name,data in sources.items()}
sources['SHA256.json']=(json.dumps(sha,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
with dest.open('xb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as arc:
    for name,data in sorted(sources.items()):
        item=tarfile.TarInfo(name)
        item.size=len(data)
        arc.addfile(item,io.BytesIO(data))
with tarfile.open(dest,'r:gz') as arc:
    assert set(sources)==set(arc.getnames())
    for name,expected in json.load(arc.extractfile('SHA256.json')).items():
        assert h(arc.extractfile(name).read())==expected==fhash(files[name])
print(dest.name,fhash(dest),len(sha),boot,sorted(counts.items()))
