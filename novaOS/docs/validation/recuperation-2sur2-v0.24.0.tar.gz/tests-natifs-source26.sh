#!/bin/sh
export RUSTC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustc' RUSTDOC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustdoc' CARGO_TARGET_DIR="$NOVAOS_TMPDIR/recuperation-2sur2-cible" CARGO_PROFILE_RELEASE_STRIP=none

set -e
for target in aarch64-apple-darwin x86_64-apple-darwin; do
 cargo test --manifest-path novaOS/user/novaauth/recuperation/Cargo.toml --release --locked --offline --target "$target" > "../preuves-recuperation-v2-cf3d218/crypto-final-$target.log" 2>&1
 cargo test --manifest-path novaOS/user/novaauth/Cargo.toml --release --locked --offline --features recuperation-lab --target "$target" > "../preuves-recuperation-v2-cf3d218/identite-final-$target.log" 2>&1
 cargo test --manifest-path novaOS/user/novaauth/service/Cargo.toml --release --locked --offline --lib --features vue-guest --target "$target" > "../preuves-recuperation-v2-cf3d218/service-final-$target.log" 2>&1
done
