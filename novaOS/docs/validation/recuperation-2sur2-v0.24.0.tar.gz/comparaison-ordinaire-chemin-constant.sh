#!/bin/sh
set -e
python3 - <<'PY'
from pathlib import Path
import subprocess,tarfile
p=Path('../tmp/recuperation-ordinaire-chemin-constant');p.mkdir()
with subprocess.Popen(['git','archive','cf3d2182c66965742ee54583bffdf84dc474e1ce','novaOS','novaFS','components'],stdout=subprocess.PIPE) as proc:
 with tarfile.open(fileobj=proc.stdout,mode='r|') as ar:ar.extractall(p,filter='data')
 assert proc.wait()==0
diff=subprocess.check_output(['git','diff','--binary','cf3d2182c66965742ee54583bffdf84dc474e1ce','94db2ca9bd77c6fc58c0b47e013010521d03c545','--','novaOS','novaFS','components'])
Path('../tmp/ordinaire-candidat-source26.patch').write_bytes(diff)
PY
export RUSTC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustc' RUSTDOC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustdoc' CARGO_TARGET_DIR="$NOVAOS_TMPDIR/recuperation-2sur2-cible" CARGO_PROFILE_RELEASE_STRIP=none

export CARGO_TARGET_DIR="$NOVAOS_TMPDIR/ordinaire-chemin-constant-cible"
cd "$NOVAOS_TMPDIR/recuperation-ordinaire-chemin-constant/novaOS"
for phase in base candidat; do
 for target in aarch64-unknown-none-softfloat x86_64-unknown-none; do
  cargo build --release --locked --offline --target "$target" > "/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/ordinaire-constant-$phase-$target.log" 2>&1
  cp "$CARGO_TARGET_DIR/$target/release/novaos" "/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/artefacts-prives-recuperation-v2/ordinaire-constant-$phase-$target.elf"
 done
 if [ "$phase" = base ]; then
  git -C .. apply "$NOVAOS_TMPDIR/ordinaire-candidat-source26.patch"
 fi
done
