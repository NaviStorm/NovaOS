#!/bin/sh
# Source26 : exporter l'arbre après application vérifiée du patch archivé.
set -e
export RUSTC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustc' RUSTDOC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustdoc' CARGO_TARGET_DIR="$NOVAOS_TMPDIR/recuperation-2sur2-cible" CARGO_PROFILE_RELEASE_STRIP=none
export NOVA_QEMU_SERVER_SEED="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/serveur" NOVA_QEMU_SERVER_PUB="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/serveur.pub" NOVA_GUEST_CERT="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/serveur.der" NOVA_AUTHORITY_CERT="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/autorite.der" NOVA_FIXTURE_CA="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/ca.der" NOVA_AUTHORITY_PUB="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/autorite.pub" NOVA_DECISION_PUB="$NOVAOS_TMPDIR/decision-c399297/decision.pub" NOVA_LAB_ALICE="/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/cles-laboratoire-politiques-0240/alice"
export CARGO_TARGET_DIR="$NOVAOS_TMPDIR/recuperation-v2-9508d72/cible" NOVA_PACKAGE_PUBLIC="/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-lancement-generique-elf/temoin-installation-rdft0q53/paquets/distribution.pub"

export NOVA_LAB_BOB='/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/cles-laboratoire-politiques-0240/bob' NOVA_VFS_OBJECTS='/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/vfs-volume-512/dossiers.bin'
cd "$NOVAOS_TMPDIR/recuperation-source26/novaOS"
export NOVA_PACKAGE_CUT='/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-lancement-generique-elf/adaptateurs/aarch64-cut.elf'
cargo build --release --locked --offline --target aarch64-unknown-none-softfloat --features novaauth-sessions-lab > /Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/build-vfs-aarch64-source26.log 2>&1
cp "$CARGO_TARGET_DIR/aarch64-unknown-none-softfloat/release/build/novaos/8c904a182e430781/out/registre-incarnation.elf" '/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/registre-source26-aarch64.elf'
export NOVA_ARCH=aarch64 NOVA_KERNEL_ELF="$CARGO_TARGET_DIR/aarch64-unknown-none-softfloat/release/novaos"
sh scripts/iso.sh novaauth-sessions /Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/vfs-aarch64-source26.iso > /Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/iso-source26-aarch64.log 2>&1
set -e
export RUSTC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustc' RUSTDOC='/Users/thierry/.rustup/toolchains/stable-aarch64-apple-darwin/bin/rustdoc' CARGO_TARGET_DIR="$NOVAOS_TMPDIR/recuperation-2sur2-cible" CARGO_PROFILE_RELEASE_STRIP=none
export NOVA_QEMU_SERVER_SEED="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/serveur" NOVA_QEMU_SERVER_PUB="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/serveur.pub" NOVA_GUEST_CERT="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/serveur.der" NOVA_AUTHORITY_CERT="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/autorite.der" NOVA_FIXTURE_CA="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/ca.der" NOVA_AUTHORITY_PUB="$NOVAOS_TMPDIR/autorite-invite-1e9fec9-cles/autorite.pub" NOVA_DECISION_PUB="$NOVAOS_TMPDIR/decision-c399297/decision.pub" NOVA_LAB_ALICE="/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/cles-laboratoire-politiques-0240/alice"
export CARGO_TARGET_DIR="$NOVAOS_TMPDIR/recuperation-v2-9508d72/cible" NOVA_PACKAGE_PUBLIC="/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-lancement-generique-elf/temoin-installation-rdft0q53/paquets/distribution.pub"

export NOVA_LAB_BOB='/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/cles-laboratoire-politiques-0240/bob' NOVA_VFS_OBJECTS='/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/vfs-volume-512/dossiers.bin'
cd "$NOVAOS_TMPDIR/recuperation-source26/novaOS"
export NOVA_PACKAGE_CUT='/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-lancement-generique-elf/adaptateurs/x86_64-cut.elf'
cargo build --release --locked --offline --target x86_64-unknown-none --features novaauth-sessions-lab > /Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/build-vfs-x86_64-source26.log 2>&1
cp "$CARGO_TARGET_DIR/x86_64-unknown-none/release/build/novaos/390027dbee5a2911/out/registre-incarnation.elf" '/Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/registre-source26-x86_64.elf'
export NOVA_ARCH=x86_64 NOVA_KERNEL_ELF="$CARGO_TARGET_DIR/x86_64-unknown-none/release/novaos"
sh scripts/iso.sh novaauth-sessions /Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/vfs-x86_64-source26.iso > /Users/thierry/SynologyDrive/Personnel/StudioProjects/OS-worktrees/preuves-recuperation-v2-cf3d218/iso-source26-x86_64.log 2>&1
