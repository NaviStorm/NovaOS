"""Contrôle et archive les quatre relectures de la mémoire du client de scripts nsh."""
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
novaos = root.parents[3]
sha = lambda data: hashlib.sha256(data).hexdigest()
def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

kernels = json.loads((root.parents[1]/'noyaux-livraison'/'sha256.json').read_text())
master = novaos/'docs/validation/services-phase3-v0.21.0-regressions-cli.tar.gz'
master_digest = digest(master)
assert master_digest == 'fa41f299037a1dd03642a7233df252aa0ca4681804ece201778934a678f36a5c'
files = {'banc/nsh_scripts.py': novaos/'tests/nsh_scripts.py', 'banc/verifier.py': Path(__file__)}
cases = []
for arch in ('aarch64','x86_64'):
    files[arch+'.log'] = root.parent/(arch+'-mesure-nsh.log')
    for sector in (512,4096):
        case = root/arch/('nsh-scripts-'+str(sector))
        row = json.loads((case/'qualification.json').read_text())
        assert (row['statut'], row['architecture'], row['secteur'], row['vcpus'], row['noyau_sha256']) == ('réussi',arch,sector,1,kernels[arch])
        assert row['resultat']['reprise'] and row['resultat']['commandes'] == 31
        for key in ('journaux','iso','image'):
            assert len(row[key]) == 2
            for name,expected in row[key].items():
                assert digest(case/name) == expected
                if key=='iso':
                    assert sha(subprocess.check_output(['/usr/bin/tar','-xOf',str(case/name),'boot/novaos.elf'])) == kernels[arch]
        serial = (case/'scripts.serial').read_bytes()
        pids = re.findall(rb'(?m)^BLOC chaine [^\r\n]* client=(\d+) ',serial)
        assert len(pids)==1 and int(pids[0])==row['resultat']['pid_client']>0
        samples = re.findall(rb'(?m)^CLI mem pid='+pids[0]+rb' privees=(\d+) pile=(\d+)\r?$',serial)
        assert len(samples)==row['resultat']['echantillons_memoire']>0
        pages = [int(a)+int(b) for a,b in samples]
        assert max(pages)==row['resultat']['pic_pages_privees_observe']
        bash = ('\r\n'.join(row['resultat']['bash'])+'\r\n').encode()
        assert bash in serial
        for p in sorted(case.rglob('*')):
            if p.is_file() and p.suffix in {'.serial','.json','.raw'}:
                files[str(p.relative_to(root))] = p
        cases.append(dict(architecture=arch,secteur=sector,pid_client=int(pids[0]),echantillons=len(samples),
                          minimum_pages=min(pages),maximum_pages=max(pages),kio_max=4*max(pages),noyau_sha256=kernels[arch]))
assert len(cases) == 4
dataio = {key:path.read_bytes() for key,path in files.items()}
summary={'mesures':cases,'vm':8,'elf_relus':8,'archive_regressions_initiale_inchangee_sha256':master_digest}
js = lambda d:(json.dumps(d,indent=2,ensure_ascii=False,sort_keys=True)+'\n').encode()
with (root/'bilan.json').open('xb') as f:
    f.write(js(summary))
dataio['bilan.json']=(root/'bilan.json').read_bytes()
manifest = {name:sha(data) for name,data in dataio.items()}
dataio['SHA256.json'] = js(manifest)
archive=root/'mesure-nsh.tar.gz'
with archive.open('xb') as f, gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz, tarfile.open(fileobj=gz,mode='w') as ar:
    for name,data in sorted(dataio.items()):
        info=tarfile.TarInfo(name)
        info.size=len(data)
        ar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as ar:
    assert set(ar.getnames())==set(dataio)
    for name,expected in json.load(ar.extractfile('SHA256.json')).items():
        assert sha(ar.extractfile(name).read())==sha(dataio[name])==expected
        if name in files:
            assert digest(files[name])==expected
print(archive.name,digest(archive),len(manifest),summary)
