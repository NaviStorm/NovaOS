import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parents[3]
arch=sys.argv[1]
suite=Path(__file__).resolve().parent/arch
suite.mkdir(exist_ok=False)
os.environ["NOVA_ARCH"]=arch
elf=Path(__file__).resolve().parents[1]/"noyaux-livraison"/(arch+".elf")
os.environ["NOVA_KERNEL_ELF"]=str(elf)
sys.path.insert(0,str(root/"tests"))
import demarrage
demarrage.BUILD=suite
kernel_sha=hashlib.sha256(elf.read_bytes()).hexdigest()
print("SHA-256",arch,kernel_sha,flush=True)
status={}
for name in ("instances","tmp_attentes","cycle_processus","abi","ipc","instances_reboot"):
    try:
        if name=="abi":
            demarrage.abi_scenario(arch,256)
        elif name=="ipc":
            import ipc
            ipc.campaign(arch,"test")
        else:
            runpy.run_path(str(root/"tests"/(name+".py")),run_name="__main__")
        status[name]="OK"
    except Exception as e:
        import traceback
        traceback.print_exc()
        status[name]=repr(e)
    print(name,status[name], flush=True)
    (suite/"bilan.json").write_text(json.dumps(dict(architecture=arch,sha256_noyau=kernel_sha,resultats=status),indent=2,ensure_ascii=False)+chr(10))
if any(v!="OK" for v in status.values()):
    sys.exit(1)
