# Précontrôle du nettoyage local · phase 3

Relevé du 15 novembre avant livraison, comparé à `origin/main` au commit `bcdfe4ccfd98c9e4a58f5cead3ce666e917ce33c`. Les listes NUL de Git (compressées) recensent tous les fichiers ignorés. Les colonnes de types donnent un aperçu selon le nom du fichier. Les états, noms des fichiers, empreintes et exemples de copies figurent dans les JSON associés. Le relevé `lsof` a détecté des utilisateurs dans le dépôt principal et le worktree de phase 3. Les chats et les processus peuvent changer après ce relevé.

| Worktree | HEAD | État | Ignorés | Journaux/résultats | Images | Décision avant livraison |
|---|---|---|---:|---:|---:|---|
| OS | `3514e7804f4c` | modifié | 929598 | 86851 | 12917 | Dépôt principal actif. Modification .gitignore et deux liens personnels. |
| novaos-abi-registry-v1 | `df88f1cfeaf0` | propre | 3408 | 32 | 0 | Copie externe intégrale des fichiers locaux non établie. |
| novaos-audit-v0300-010ae39 | `a602051c9f3f` | propre | 0 | 0 | 0 | HEAD hors de l’ascendance de origin/main. |
| novaos-fusion-abi-tmp-0210 | `bcdfe4ccfd98` | propre | 67 | 13 | 4 | Quatre nouveaux journaux et images ISO des ELF v0.20.0. Archive externe intégrale non démontrée. |
| novaos-fusion-smp-835b9d9 | `573137c1f567` | propre | 137857 | 3989 | 1059 | Arborescence historique avec liens et/ou FIFO. La restauration externe complète de ces objets n’a pas été vérifiée. |
| novaos-instances-0210 | `6b75a2bd0a44` | propre | 3976 | 161 | 5 | Fichiers postérieurs au manifeste de migration, dont les traces de reprise du Cortex-A72. |
| novaos-integration-abi-tmp-0210 | `3839f1a2525e` | propre | 14810 | 719 | 280 | Copie externe intégrale des fichiers locaux non établie. |
| novaos-integration-instances-0210 | `a6df93fb8687` | propre | 0 | 0 | 0 | Candidat après livraison, 0 ignorés, 1208 suivis vérifiés hors du worktree. |
| novaos-materiel-0180-010ae39 | `a467fe686758` | propre | 12217 | 662 | 60 | Arborescence historique avec liens et/ou FIFO. La restauration externe complète de ces objets n’a pas été vérifiée. |
| novaos-nvme-phase1-0190-d6a84a3 | `8839cff384e6` | propre | 12239 | 2151 | 376 | Candidat après livraison, 12239 ignorés, 1127 suivis vérifiés hors du worktree. |
| novaos-preparation-0210 | `622d8d97e547` | propre | 0 | 0 | 0 | HEAD hors de l’ascendance de origin/main. |
| novaos-rust-system-0200 | `6533078fc0fe` | propre | 6487 | 80 | 10 | Candidat après livraison, 6487 ignorés, 1162 suivis vérifiés hors du worktree. |
| novaos-rust-system-0200-phase2 | `b46ddf190267` | propre | 2061 | 29 | 0 | Candidat après livraison, 2061 ignorés, 1175 suivis vérifiés hors du worktree. |
| novaos-services-0210-phase3 | `93306cfd46d8` | modifié | 1546 | 14 | 2 | Branche de phase 3 active. Comptes provisoires, campagnes en cours. |
| novaos-tmp-prive-0210 | `35f7d9619f11` | propre | 3303 | 521 | 262 | Copie externe intégrale des fichiers locaux non établie. |

Trois worktrees de qualification historiques possèdent une copie externe de tous leurs fichiers ignorés, physiquement lisible sous `OS-worktrees/.verifications/objets-sha256/`. Les 20 787 originaux et leurs copies ont été relus (3 605 967 766 octets de fichiers locaux). L’emplacement est distinct du worktree sur le même volume APFS. L’inventaire des chemins, types, permissions, propriétaires et drapeaux de ces trois arbres concorde intégralement avec les manifestes de migration. La vérification ne couvre pas une panne physique du Mac. Le worktree détaché de la fusion des instances contient exclusivement les 1 208 fichiers du commit et ses répertoires versionnés. Pour ces quatre worktrees, les 4 672 contenus suivis ont été comparés aux blobs extérieurs conservés dans `OS/.git`; l’ascendance de `origin/main` a été vérifiée pour les quatre commits.

Ce précontrôle ne supprime rien. Les bilans de migration historiques conservent les manifestes des fichiers et des liens. La publication et le contrôle d’inactivité doivent précéder tout retrait.
