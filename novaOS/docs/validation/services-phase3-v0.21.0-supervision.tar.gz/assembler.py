"""Assemble les preuves réellement lues côté hôte à partir du lot validé."""
import gzip, hashlib, io, json, os, re, subprocess, tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
build = root.parent
dest = build.parent / 'docs/validation/services-phase3-v0.21.0-supervision.tar.gz'
manifest = json.loads((root/'noyaux-livraison/sha256.json').read_bytes())
def sha(data):
    return hashlib.sha256(data).hexdigest()
def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def add(path, prefix):
    files[prefix + '/' + str(path.relative_to(root / prefix))] = path
files = {}
metrics = []
for arch, digest_elf in manifest.items():
    elf = root/'noyaux-livraison'/(arch+'.elf')
    assert digest(elf) == digest_elf
    for cpu in (1, 2, 4):
        for sector in (512, 4096):
            name = f'{arch}-{cpu}-{sector}'
            cell = root/'matrice-publication'/name
            rows = json.loads((cell/'resultats.json').read_bytes())
            assert len(rows) == 4 + (cpu == 2) and digest(cell/'novaos.elf') == digest_elf
            extracted = {}
            for n, row in enumerate(rows):
                profile = row['profil']
                assert (row['architecture'],row['vcpus'],row['secteur'],row['noyau_sha256']) == (arch,cpu,sector,digest_elf)
                iso = cell/(profile+'.iso')
                if profile not in extracted:
                    assert sha(subprocess.check_output(['/usr/bin/tar','-xOf',iso,'boot/novaos.elf'])) == digest_elf
                    extracted[profile] = digest(iso)
                assert row['iso_sha256'] == extracted[profile]
                serial = cell/f'{n}-{profile}.serial'
                snap = cell/f'{n}-{profile}.raw.gz'
                assert digest(serial) == row['journal_sha256']
                assert sha(gzip.decompress(snap.read_bytes())) == row['image_sha256']
                if profile == 'services-test':
                    ram = row['memoire']
                    metrics.append((arch,cpu,sector,ram['pic_cadres'],ram['allocations'],row['cadres_plateforme']))
                for path in (snap, serial):
                    add(path, 'matrice-publication')
            add(cell/'resultats.json', 'matrice-publication')
for prefix in ('noyaux-livraison','reg-tmp-livraison','correctifs','reg-noyau-livraison'):
    for path in sorted((root/prefix).rglob('*')):
        if path.is_file() and path.suffix not in ('.iso','.img','.elf','.raw'):
            add(path,prefix)
for arch in manifest:
    add(root/'noyaux-livraison'/(arch+'.elf'),'noyaux-livraison')
    assert len(list((root/'reg-tmp-livraison'/('tmp_prive-'+arch)).glob('*.serial'))) == 4
    path = root/'politique'/(arch+'-94873f3.log')
    assert b'12 passed' in path.read_bytes()
    add(path,'politique')
    reg = json.loads((root/'reg-noyau-livraison'/arch/'bilan.json').read_bytes())
    assert reg['sha256_noyau']==manifest[arch] and len(reg['resultats'])==6 and set(reg['resultats'].values())=={'OK'}
add(root/'noyaux-compacts/segments.json','noyaux-compacts')
add(root/'pollution-console/incident-dep.tar.gz', 'pollution-console')
for path in (root/'coupure-apres-cat').rglob('*'):
    if path.is_file() and path.suffix in ('.gz','.json','.serial'):
        add(path, 'coupure-apres-cat')
add(root/'audit-worktrees/avant-livraison.md','audit-worktrees')
for p in sorted((root/'reg-cli/mesure-nsh').rglob('*')):
    if p.is_file() and p.suffix in ('.gz','.json','.serial','.log','.py'):
        add(p,'reg-cli/mesure-nsh')
for arch, cpu, sector in [(a,n,s) for a in manifest for n in (1,2,4) for s in (512,4096)]:
    name=f'{arch}-{cpu}-{sector}.log'
    path=root/'matrice-livraison'/name
    if b'panicked at novaOS/tests/tmp_prive_oracle.rs:' in path.read_bytes():
        add(path,'matrice-livraison')
files['assembler.py'] = Path(__file__).resolve()
summary = {'vm_supervision':52,'noyaux':manifest,'mesures_services_test':metrics}
report = root/'mesures-validees.json'
report.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
files['mesures.json'] = report
sums = {name:digest(path) for name,path in sorted(files.items())}
md = (json.dumps(sums,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode()
with dest.open('xb') as out, gzip.GzipFile(fileobj=out, mode='wb', mtime=0, filename='') as gz, tarfile.open(mode='w',fileobj=gz) as tar:
    def item(name,data):
        header=tarfile.TarInfo(name);header.size=len(data);tar.addfile(header,io.BytesIO(data))
    for name,path in sorted(files.items()):
        item(name,path.read_bytes())
    item('SHA256.json',md)
with tarfile.open(dest,'r:gz') as archive:
    assert set(archive.getnames()) == set(files)|{'SHA256.json'}
    for name, stamp in json.load(archive.extractfile('SHA256.json')).items():
        assert sha(archive.extractfile(name).read()) == stamp == digest(files[name])
print(dest, digest(dest), len(files), metrics)
