// This file is part of the uutils diffutils package.
//
// For the full copyright and license information, please view the LICENSE-*
// files that was distributed with this source code.

use crate::bre::Bre;
use regex::Regex;
use std::{
    borrow::Cow,
    ffi::{OsStr, OsString},
    io::Write,
};
use unicode_width::UnicodeWidthStr;

/// Write the input line to an output stream, replacing tabs by spaces.
/// Correctly handle multi-bytes characters.
/// The spaces are written in small chunks, so a huge tab size does not
/// need a huge buffer.
/// This assumes that line does not contain any line breaks (if it does, the result is undefined).
pub fn do_expand_tabs<W: Write>(
    output: &mut W,
    line: &[u8],
    tabsize: usize,
) -> std::io::Result<()> {
    const SPACES: [u8; 64] = [b' '; 64];
    let tab = b'\t';
    let mut offset = 0;

    let mut iter = line.split(|c| *c == tab).peekable();
    while let Some(chunk) = iter.next() {
        match std::str::from_utf8(chunk) {
            Ok(s) => offset += UnicodeWidthStr::width(s),
            Err(_) => offset += chunk.len(),
        }
        output.write_all(chunk)?;
        if iter.peek().is_some() {
            let mut spaces = tabsize - offset % tabsize;
            while spaces > 0 {
                let n = spaces.min(SPACES.len());
                output.write_all(&SPACES[..n])?;
                spaces -= n;
            }
            offset = 0;
        }
    }

    Ok(())
}

/// Write a single line to an output stream, expanding tabs to space if necessary.
/// This assumes that line does not contain any line breaks
/// (if it does and tabs are to be expanded to spaces, the result is undefined).
pub fn do_write_line<W: Write>(
    output: &mut W,
    line: &[u8],
    expand_tabs: bool,
    tabsize: usize,
) -> std::io::Result<()> {
    if expand_tabs {
        do_expand_tabs(output, line, tabsize)
    } else {
        output.write_all(line)
    }
}

/// Quotes a file name for the headers of the diff output: a name containing
/// spaces, double quotes, backslashes, control characters or non-ASCII bytes
/// is written between double quotes with C-style escapes, other names are
/// written as is. On Windows, backslashes separate path components and are
/// left alone.
#[must_use]
pub fn quote_file_name(name: &[u8]) -> Cow<'_, [u8]> {
    const SPECIAL_BACKSLASH: bool = cfg!(not(windows));
    let needs_quotes = |byte: u8| {
        byte <= b' ' || byte == b'"' || (byte == b'\\' && SPECIAL_BACKSLASH) || byte >= 0x80
    };
    if !name.iter().copied().any(needs_quotes) {
        return Cow::Borrowed(name);
    }
    let mut quoted = Vec::with_capacity(name.len() + 8);
    quoted.push(b'"');
    for &byte in name {
        let escape = match byte {
            b'"' => b'"',
            b'\\' if SPECIAL_BACKSLASH => b'\\',
            0x07 => b'a',
            0x08 => b'b',
            b'\t' => b't',
            b'\n' => b'n',
            0x0b => b'v',
            0x0c => b'f',
            b'\r' => b'r',
            b' ' => {
                quoted.push(b' ');
                continue;
            }
            byte if needs_quotes(byte) => {
                quoted.extend_from_slice(format!("\\{byte:03o}").as_bytes());
                continue;
            }
            byte => {
                quoted.push(byte);
                continue;
            }
        };
        quoted.extend_from_slice(&[b'\\', escape]);
    }
    quoted.push(b'"');
    Cow::Owned(quoted)
}

/// Appends a file header line of the context or unified formats, such as
/// `--- name\ttimestamp`, to `output`. A label replaces both the name and the
/// timestamp, and is written as it is, without quoting.
pub fn write_file_header(
    output: &mut Vec<u8>,
    marker: &str,
    name: &OsStr,
    label: Option<&OsStr>,
    timestamp: &str,
) {
    output.extend_from_slice(marker.as_bytes());
    output.push(b' ');
    if let Some(label) = label {
        output.extend_from_slice(label.as_encoded_bytes());
    } else {
        output.extend_from_slice(&quote_file_name(name.as_encoded_bytes()));
        output.push(b'\t');
        output.extend_from_slice(timestamp.as_bytes());
    }
    output.push(b'\n');
}

/// Puts `name` between single quotes, writing a quote in it as `'\''`.
#[must_use]
pub fn single_quote(name: &[u8]) -> Vec<u8> {
    let mut quoted = Vec::with_capacity(name.len() + 2);
    quoted.push(b'\'');
    for &byte in name {
        if byte == b'\'' {
            quoted.extend_from_slice(br"'\''");
        } else {
            quoted.push(byte);
        }
    }
    quoted.push(b'\'');
    quoted
}

/// Quotes a command line argument the way a shell would need it, for the
/// headers that repeat the options of a directory comparison.
#[must_use]
pub fn quote_shell_argument(arg: &[u8]) -> Cow<'_, [u8]> {
    const SPECIAL: &[u8] = b"^*?!=()|&;<>`\\'\"$[";
    let is_special = |byte: &u8| *byte <= b' ' || *byte == 0x7f || SPECIAL.contains(byte);
    let special_start = matches!(arg.first(), Some(b'~' | b'#'));
    if !special_start && !arg.iter().any(is_special) && !arg.is_empty() {
        return Cow::Borrowed(arg);
    }
    let mut quoted = Vec::with_capacity(arg.len() + 2);
    let only_single_quotes = arg
        .iter()
        .filter(|byte| is_special(byte))
        .all(|&byte| byte == b'\'');
    if arg.contains(&b'\'') && only_single_quotes {
        quoted.push(b'"');
        quoted.extend_from_slice(arg);
        quoted.push(b'"');
    } else {
        quoted.push(b'\'');
        for &byte in arg {
            if byte == b'\'' {
                quoted.extend_from_slice(b"'\\''");
            } else {
                quoted.push(byte);
            }
        }
        quoted.push(b'\'');
    }
    Cow::Owned(quoted)
}

/// Returns `name` in lowercase, to match file names ignoring case.
pub fn fold_file_name_case(name: &OsStr) -> Vec<u8> {
    match name.to_str() {
        Some(name) => name.to_lowercase().into_bytes(),
        None => name.as_encoded_bytes().to_ascii_lowercase(),
    }
}

/// Finds the lines shown after hunk headers by `-F` and `-p`: the nearest
/// line of the old file preceding a hunk that matches one of the patterns.
pub struct FunctionLineFinder<'a> {
    lines: Vec<&'a [u8]>,
    patterns: &'a [Bre],
    /// Index of the first line not examined yet.
    next_line: usize,
    last_match: Option<&'a [u8]>,
}

impl<'a> FunctionLineFinder<'a> {
    /// Maximum number of bytes of a function line that are shown.
    const MAX_WIDTH: usize = 40;

    /// Returns `None` when there are no patterns, so no function lines.
    pub fn new(old_text: &'a [u8], patterns: &'a [Bre]) -> Option<Self> {
        if patterns.is_empty() {
            return None;
        }
        Some(Self {
            lines: old_text.split(|&byte| byte == b'\n').collect(),
            patterns,
            next_line: 0,
            last_match: None,
        })
    }

    /// Returns the text to show after the header of a hunk starting at
    /// `first_line` (1-based) of the old file, if any. Hunks must be queried
    /// in increasing order.
    pub fn find(&mut self, first_line: usize) -> Option<Vec<u8>> {
        let end = first_line.saturating_sub(1).min(self.lines.len());
        for line in &self.lines[self.next_line.min(end)..end] {
            if self.patterns.iter().any(|pattern| pattern.is_match(line)) {
                self.last_match = Some(line);
            }
        }
        self.next_line = self.next_line.max(end);
        // C's isspace(): unlike `is_ascii_whitespace`, it includes vertical tab.
        let is_space = |byte: &u8| byte.is_ascii_whitespace() || *byte == b'\x0b';
        let line = self.last_match?;
        let start = line
            .iter()
            .position(|byte| !is_space(byte))
            .unwrap_or(line.len());
        let line = &line[start..];
        let line = &line[..line.len().min(Self::MAX_WIDTH)];
        let end = line
            .iter()
            .rposition(|byte| !is_space(byte))
            .map_or(0, |last| last + 1);
        Some(line[..end].to_vec())
    }
}

/// How a modification time is rendered in a diff header.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TimestampStyle {
    /// `2026-03-05 07:08:09.500000000 +0100`
    Iso,
    /// `Thu Mar  5 07:08:09 2026`
    Traditional,
}

/// Returns whether the locale selected for `category` (e.g. `LC_TIME`) is the
/// POSIX one, following the `LC_ALL` > category > `LANG` precedence, where an
/// empty variable counts as unset.
pub fn is_posix_locale(category: &str) -> bool {
    let locale = ["LC_ALL", category, "LANG"]
        .into_iter()
        .find_map(|name| std::env::var(name).ok().filter(|value| !value.is_empty()))
        .unwrap_or_else(|| "C".to_string());
    locale == "C" || locale == "POSIX"
}

/// Retrieves the modification time of the input file specified by file path
/// A file that was `missing` and compared as empty is dated at the Unix Epoch.
/// If an error occurs, it returns the current system time
pub fn get_modification_time(file_path: &str, style: TimestampStyle, missing: bool) -> String {
    use chrono::{DateTime, Local};
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    let modification_time: SystemTime = if missing {
        UNIX_EPOCH
    } else {
        fs::metadata(file_path)
            .and_then(|m| m.modified())
            .unwrap_or(SystemTime::now())
    };

    let modification_time: DateTime<Local> = modification_time.into();
    let format = match style {
        TimestampStyle::Iso => "%Y-%m-%d %H:%M:%S%.9f %z",
        TimestampStyle::Traditional => "%a %b %e %H:%M:%S %Y",
    };
    modification_time.format(format).to_string()
}

pub fn format_failure_to_read_input_file(
    executable: &OsString,
    filepath: &OsString,
    error: &std::io::Error,
) -> String {
    // std::io::Error's display trait outputs "{detail} (os error {code})"
    // but we want only the {detail} (error string) part
    let error_code_re = Regex::new(r"\ \(os\ error\ \d+\)$").unwrap();
    format!(
        "{}: {}: {}",
        executable.to_string_lossy(),
        filepath.to_string_lossy(),
        error_code_re.replace(error.to_string().as_str(), ""),
    )
}

pub fn report_failure_to_read_input_file(
    executable: &OsString,
    filepath: &OsString,
    error: &std::io::Error,
) {
    eprintln!(
        "{}",
        format_failure_to_read_input_file(executable, filepath, error)
    );
}

#[cfg(test)]
pub mod testcmds {
    // Command construction wrapper that provides some validation and non-obscure, "fail fast"
    // feedback and error messages.
    use std::any::Any;
    use std::io::Write;
    use std::panic::catch_unwind;
    use std::process::{Command, Stdio};
    use std::sync::LazyLock;

    pub struct CmdFactory {
        cmd: &'static str,
        validated_once: LazyLock<Result<(), String>>,
        validate: fn(&CmdFactory) -> (),
    }

    impl CmdFactory {
        pub fn new(&self) -> Command {
            match &*self.validated_once {
                Ok(()) => Command::new(self.cmd),
                Err(errmsg) => panic!(
                    "'{}' validation failed in earlier thread/test: {}",
                    self.cmd, errmsg
                ),
            }
        }
        // "self" is not compatible with static initialization
        fn try_catch_validate(cmd: &CmdFactory) -> Result<(), String> {
            // Note catch_unwind() does _not_ hide error messages, stack traces, etc.
            catch_unwind(|| {
                let _ = (cmd.validate)(cmd);
            })
            .map_err(find_panic_message)
        }
    }

    fn find_panic_message(payload: Box<dyn Any + Send>) -> String {
        // https://github.com/rust-lang/rust/blob/1.95.0/library/std/src/panicking.rs#L771
        if let Some(&s) = payload.downcast_ref::<&'static str>() {
            String::from(s)
        } else if let Some(s) = payload.downcast_ref::<String>() {
            s.clone()
        } else {
            format!(
                "Unusual panic payload type {:?}, look for the first thread/test that failed",
                payload.type_id(),
            )
        }
    }

    pub static PATCH_CMD: CmdFactory = CmdFactory {
        cmd: if cfg!(target_os = "macos") {
            "gpatch" // brew install gpatch
        } else {
            "patch"
        },
        validated_once: LazyLock::new(|| CmdFactory::try_catch_validate(&PATCH_CMD)),

        validate: (|myself| {
            let output = Command::new(myself.cmd)
                .arg("--version")
                .output()
                .expect(format!("`{} --version` failed", myself.cmd).as_str());
            // Non-GNU versions have subtle differences. When some newlines are missing in some test
            // patches, the macOS version can even stall the whole test run.
            assert!(output.stdout.starts_with(b"GNU patch"));
            assert!(output.status.success());
        }),
    };

    pub static ED_CMD: CmdFactory = CmdFactory {
        cmd: "ed",
        validated_once: LazyLock::new(|| CmdFactory::try_catch_validate(&ED_CMD)),

        validate: (|myself| {
            let mut child = Command::new(myself.cmd)
                .arg("!echo hello_ed")
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .spawn()
                .expect("Failed to start 'ed' command");

            let mut stdin = child.stdin.take().unwrap();
            writeln!(stdin, "1p\nq").expect("Failed to send command to 'ed'");

            let output = child
                .wait_with_output()
                .expect("Failed to read 'ed' stdout");
            assert_eq!(String::from_utf8_lossy(&output.stdout), "9\nhello_ed\n");
        }),
    };
}

#[cfg(test)]
mod tests {
    use super::*;

    mod expand_tabs {
        use super::*;
        use pretty_assertions::assert_eq;

        fn expand(line: &[u8], tabsize: usize) -> Vec<u8> {
            let mut output = Vec::new();
            assert!(do_expand_tabs(&mut output, line, tabsize).is_ok());
            output
        }

        fn assert_tab_expansion(line: &str, tabsize: usize, expected: &str) {
            assert_eq!(expand(line.as_bytes(), tabsize), expected.as_bytes());
        }

        #[test]
        fn basics() {
            assert_tab_expansion("foo barr   baz", 8, "foo barr   baz");
            assert_tab_expansion("foo\tbarr\tbaz", 8, "foo     barr    baz");
            assert_tab_expansion("foo\tbarr\tbaz", 5, "foo  barr baz");
            assert_tab_expansion("foo\tbarr\tbaz", 2, "foo barr  baz");
        }

        #[test]
        fn multibyte_chars() {
            assert_tab_expansion("foo\tépée\tbaz", 8, "foo     épée    baz");
            assert_tab_expansion("foo\t😉\tbaz", 5, "foo  😉   baz");

            // Note: The Woman Scientist emoji (👩‍🔬) is a ZWJ sequence combining
            // the Woman emoji (👩) and the Microscope emoji (🔬). On supported platforms
            // it is displayed as a single emoji and has a print size of 2 columns.
            // Terminal emulators tend to not support this, and display the two emojis
            // side by side, thus accounting for a print size of 4 columns, but the
            // unicode_width crate reports a correct size of 2.
            assert_tab_expansion("foo\t👩‍🔬\tbaz", 6, "foo   👩‍🔬    baz");
        }

        #[test]
        fn invalid_utf8() {
            // [240, 240, 152, 137] is an invalid UTF-8 sequence, so it is handled as 4 bytes
            assert_eq!(
                expand(&[240, 240, 152, 137, 9, 102, 111, 111], 8),
                &[240, 240, 152, 137, 32, 32, 32, 32, 102, 111, 111]
            );
        }

        #[test]
        fn huge_tabsize() {
            // The spaces are streamed to the writer, so the largest accepted
            // tab size neither overflows nor needs a huge buffer up front.
            let mut buf = [0u8; 1000];
            let mut output = &mut buf[..];
            assert!(do_expand_tabs(&mut output, b"a\tb\tc", crate::params::MAX_TABSIZE).is_err());
            let mut expected = b"a".to_vec();
            expected.resize(1000, b' ');
            assert_eq!(buf[..], expected[..]);
        }
    }

    mod quoting {
        use super::*;
        use pretty_assertions::assert_eq;

        fn quoted_name(name: &[u8]) -> String {
            String::from_utf8(quote_file_name(name).into_owned()).unwrap()
        }

        fn quoted_arg(arg: &str) -> String {
            String::from_utf8(quote_shell_argument(arg.as_bytes()).into_owned()).unwrap()
        }

        #[test]
        fn file_names() {
            assert_eq!(quoted_name(b"src/main.rs"), "src/main.rs");
            assert_eq!(quoted_name(b"why?*$'#~"), "why?*$'#~");
            assert_eq!(quoted_name(b"two words"), r#""two words""#);
            assert_eq!(quoted_name(b"say \"hi\""), r#""say \"hi\"""#);
            if cfg!(windows) {
                assert_eq!(quoted_name(b"C:\\temp"), r"C:\temp");
                assert_eq!(quoted_name(b"C:\\my docs"), r#""C:\my docs""#);
            } else {
                assert_eq!(quoted_name(b"C:\\temp"), r#""C:\\temp""#);
            }
            assert_eq!(
                quoted_name(b"\x07\x08\t\n\x0b\x0c\r"),
                r#""\a\b\t\n\v\f\r""#
            );
            assert_eq!(quoted_name(b"\x1bx\x7f"), "\"\\033x\x7f\"");
            assert_eq!(quoted_name("caf\u{e9}".as_bytes()), r#""caf\303\251""#);
            assert_eq!(quoted_name(b"\xfe"), r#""\376""#);
        }

        #[test]
        fn shell_arguments() {
            assert_eq!(quoted_arg("-u"), "-u");
            assert_eq!(quoted_arg("a,b:c@d%e+f{g}h]/i.j"), "a,b:c@d%e+f{g}h]/i.j");
            assert_eq!(quoted_arg("x~#"), "x~#");
            assert_eq!(quoted_arg("~x"), "'~x'");
            assert_eq!(quoted_arg("#x"), "'#x'");
            assert_eq!(quoted_arg("^fn (main|init)"), "'^fn (main|init)'");
            assert_eq!(quoted_arg("--width=9"), "'--width=9'");
            assert_eq!(quoted_arg(""), "''");
            assert_eq!(quoted_arg("don't"), "\"don't\"");
            assert_eq!(quoted_arg("don't $pay"), "'don'\\''t $pay'");
        }

        #[test]
        fn single_quotes() {
            assert_eq!(single_quote(b"plain"), b"'plain'");
            assert_eq!(single_quote(b"it's"), br"'it'\''s'");
            assert_eq!(single_quote(b""), b"''");
        }
    }

    mod write_line {
        use super::*;
        use pretty_assertions::assert_eq;

        fn assert_line_written(line: &str, expand_tabs: bool, tabsize: usize, expected: &str) {
            let mut output: Vec<u8> = Vec::new();
            assert!(do_write_line(&mut output, line.as_bytes(), expand_tabs, tabsize).is_ok());
            assert_eq!(output, expected.as_bytes());
        }

        #[test]
        fn basics() {
            assert_line_written("foo bar baz", false, 8, "foo bar baz");
            assert_line_written("foo bar\tbaz", false, 8, "foo bar\tbaz");
            assert_line_written("foo bar\tbaz", true, 8, "foo bar baz");
        }
    }

    mod modification_time {
        use super::*;

        #[test]
        fn set_time() {
            use chrono::{DateTime, Local};
            use std::time::SystemTime;
            use tempfile::NamedTempFile;

            let temp = NamedTempFile::new().unwrap();
            // set file modification time equal to current time
            let current = SystemTime::now();
            let _ = temp.as_file().set_modified(current);

            // format current time
            let current: DateTime<Local> = current.into();
            let current: String = current.format("%Y-%m-%d %H:%M:%S%.9f %z").to_string();

            // verify
            assert_eq!(
                current,
                get_modification_time(&temp.path().to_string_lossy(), TimestampStyle::Iso, false)
            );
        }

        #[test]
        fn invalid_file() {
            use chrono::{DateTime, Local};
            use std::time::SystemTime;

            let invalid_file = "target/utils/invalid-file";

            // store current time before calling `get_modification_time`
            // Because the file is invalid, it will return SystemTime::now()
            // which will be greater than previously saved time
            let current_time: DateTime<Local> = SystemTime::now().into();
            let m_time: DateTime<Local> =
                get_modification_time(invalid_file, TimestampStyle::Iso, false)
                    .parse()
                    .unwrap();

            assert!(m_time > current_time);
        }
    }
}
