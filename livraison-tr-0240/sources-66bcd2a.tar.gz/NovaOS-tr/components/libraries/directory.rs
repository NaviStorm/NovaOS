use crate::{fileapi::Client, protocol as w, runtime as rt};
use alloc::{string::String, vec::Vec};
pub struct Entry {
    pub name: String,
    pub stat: w::Frame,
}
pub fn entries(c: &mut Client, h: u64) -> rt::Result<Vec<Entry>> {
    entries_bounded(c, h, usize::MAX)
}

pub fn entries_bounded(c: &mut Client, h: u64, limit: usize) -> rt::Result<Vec<Entry>> {
    let mut rows = Vec::new();
    visit_names(c, h, limit, |c, name| {
        let stat = c.at(w::LOOKUP_AT, h, name.as_bytes(), 0)?;
        rows.try_reserve(1).map_err(|_| rt::NO_MEMORY)?;
        rows.push(Entry {
            name: String::from(name),
            stat,
        });
        Ok(())
    })?;
    Ok(rows)
}

/// Le curseur et le nom en cours sont les seuls tampons retenus pour une liste filtrée.
pub fn visit_names(
    c: &mut Client,
    h: u64,
    limit: usize,
    mut visit: impl FnMut(&mut Client, &str) -> rt::Result<()>,
) -> rt::Result<()> {
    let mut remaining = limit;
    let mut name = Vec::new();
    let mut after = Vec::new();
    let mut generation = 0;
    loop {
        name.clear();
        loop {
            let a = c.readdir_fragment(h, &after, name.len() as u64, generation)?;
            generation = w::word(&a, 24);
            let n = w::length(&a);
            let len = w::word(&a, 32);
            if len == 0 && name.is_empty() {
                return Ok(());
            }
            if n == 0 || n > w::FRAGMENT || len > 255 || name.len() as u64 + n as u64 > len {
                return Err(rt::REFUSED);
            }
            name.extend_from_slice(&a[w::PAYLOAD..w::PAYLOAD + n]);
            if name.len() as u64 == len {
                break;
            }
        }
        remaining = remaining.checked_sub(1).ok_or(rt::LIMIT)?;
        visit(c, core::str::from_utf8(&name).map_err(|_| rt::REFUSED)?)?;
        core::mem::swap(&mut name, &mut after);
    }
}

/// Traverser depuis une capacité épinglée en ne gardant qu'un curseur dérivé.
/// La profondeur persistante ne consomme pas un handle ouvert par ancêtre.
pub fn within<T>(
    client: &mut Client,
    root: u64,
    path: &[String],
    rights: u8,
    f: impl FnOnce(&mut Client, u64) -> rt::Result<T>,
) -> rt::Result<T> {
    let mut dir = root;
    for name in path {
        let step = client.directory(dir, name.as_bytes(), rights);
        if dir != root {
            client.simple(w::DIR_CLOSE, dir)?;
        }
        dir = step?;
    }
    let result = f(client, dir);
    if dir != root {
        client.simple(w::DIR_CLOSE, dir)?;
    }
    result
}

pub fn cwd(c: &mut Client) -> rt::Result<String> {
    let mut buf = alloc::vec::Vec::new();
    let mut generation = 0;
    loop {
        let a = c.cwd_fragment(buf.len() as u64, generation)?;
        generation = w::word(&a, 24);
        let n = w::length(&a);
        let total = w::word(&a, 32);
        if total > 8192 || n > w::FRAGMENT || buf.len() as u64 + n as u64 > total {
            return Err(rt::REFUSED);
        }
        buf.extend_from_slice(&a[w::PAYLOAD..w::PAYLOAD + n]);
        if buf.len() as u64 == total {
            break;
        }
        if n == 0 {
            return Err(rt::REFUSED);
        }
    }
    String::from_utf8(buf).map_err(|_| rt::BAD_ARGUMENT)
}
