#![no_std]
extern crate alloc;
#[path = "../../novaOS/user/heap.rs"]
mod heap;
#[path = "../../novaOS/user/storage/runtime.rs"]
pub mod runtime;
fn allocation_probe() {}
pub mod command;
pub mod console;
#[path = "../../novaOS/user/storage/fileapi.rs"]
pub mod fileapi;
pub mod process;
#[path = "../../novaOS/abi/files.rs"]
pub mod protocol;
#[path = "../../novaOS/abi/terminal.rs"]
pub mod tty;

pub mod directory;
pub mod options;
pub mod vi_wire;

pub mod documentation;

#[path = "../coreutils/tr/engine.rs"]
pub mod tr;
